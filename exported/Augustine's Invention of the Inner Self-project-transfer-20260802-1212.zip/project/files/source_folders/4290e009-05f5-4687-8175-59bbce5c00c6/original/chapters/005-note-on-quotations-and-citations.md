# Note on Quotations and Citations

## **Note on Quotations and Citations**

All translations from ancient and medieval texts are my own, as are all other translations, unless an English edition is given in the bibliography. Italics in quotations are mine (their purpose being usually to emphasize the part of the quotation on which my exegesis turns). Citations from ancient texts omit the chapter number where redundant: for example *Confessions*, book 7, chapter 10, section 16 is cited *Conf*. 7:16.
