# Part II. Augustine: Inventing The Inner Self

## **PART II AUGUSTINE: INVENTING THE INNER SELF**
