# Copyright Page

Oxford New York  
Athens Auckland Bangkok Bogotá Buenos Aires Calcutta  
Cape Town Chennai Dar es Salaam Delhi Florence Hong Kong Istanbul  
Karachi Kuala Lumpur Madrid Melbourne Mexico City Mumbai  
Nairobi Paris São Paulo Singapore Taipei Tokyo Toronto Warsaw

and associated companies in  
Berlin Ibadan

Copyright © 2000 by Phillip Cary

Published by Oxford University Press. Inc.  
198 Madison Avenue, New York, New York 10016

Oxford is a registered trademark of Oxford University Press

All rights reserved. No part of this publication may be reproduced,  
stored in a retrieval system, or transmitted in any form or by any means,  
electronic, mechanical, photocopying, recording, or otherwise,  
without the prior permission of Oxford University Press.

First issued as an Oxford University Press paperback, 2003  
Library of Congress Cataloging-in-Publication Data  
Cary, Phillip. 1958-  
Augustine’s invention of the inner self: the legacy of a  
Christian platonist / Phillip Cary.  
p. cm.

Includes bibliographical references and index.  
ISBN 0-19-513206-8 0-19-515861-X (pbk.)  
1. Augustine, Saint. Bishop of Hippo—Contributions in doctrine  
of soul. 2. Soul—History of doctrines—Early church, ca. 30-600.  
I. Title.

BT741.2.C37 1999 99-21119  
189’.2—dc21

1 3 5 7 9 8 6 4 2  
Printed in the United States of America  
on acid-free paper
