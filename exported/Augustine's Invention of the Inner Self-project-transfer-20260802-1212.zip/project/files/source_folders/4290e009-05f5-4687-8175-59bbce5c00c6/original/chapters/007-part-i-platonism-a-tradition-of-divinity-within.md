# Part I. Platonism: A Tradition of Divinity Within

## **PART I PLATONISM: A TRADITION OF DIVINITY WITHIN**
