# Select Bibliography

- Th. W.   Adorno  , Prisms , transl. S. and   S.   Weber  ,   Cambridge, MA  :   MIT  ,   1967  .

- Hannah   Arendt  , The Origins of Totalitarianism ,   San Diego  :   Harvest  ,   1973 (1st ed. 1951).

- Hannah   Arendt  , The Human Condition ,   University of Chicago Press  ,   1958  .

- Hannah   Arendt  , Between Past and Future ,   Ithaca, NY  :   Cornell University Press,   1954  .

- Hannah   Arendt  , Eichmann in Jerusalem , A Report on the Banality of Evil,   New York  : Penguin  ,   1963  .

- Hannah   Arendt  , Crises of the Republic ,   San Diego  :   Harcourt  ,   1972  .

- Hannah   Arendt  , Men in Dark Times ,   San Diego  :   Harcourt Brace  ,   1983  .

- Hannah   Arendt  , Lectures on Kant's Political Philosophy ,  ed.    R.    Beiner  ,    University  of Chicago Press  ,   1982  .

- Hannah   Arendt  , The Promise of Politics ,   New York  :   Schocken  ,   2005  .

- Aristotle  , Metaphysics,  Text  with  introduction  and  commentary, ed.    D.    Ross  ,  2  vols., Oxford  :   Clarendon  ,   1958  .

- Aristotle  , Nicomachean Ethics , English transl.   H.   Rackham  ,   Cambridge, MA  :   Harvard University Press (Loeb's Classical Library),   1934  .

- Aristotle  , Nicomachean Ethics , transl. and ed.   T.   Irwin  ,   Indianapolis  :   Hackett  ,   1999  .

- Aristotle  , Politics , English transl.   H.   Rackham  ,   Cambridge, MA  :   Harvard University Press (Loeb's Classical Library),   1944  .

- Muhammad   Asad  , Islam  at  the  Crossroads ,  orig.    New  York  1934,  Arab  transl.  1941, Islamic Book Trust,   1982  .

- Peter   Awn  , Satan's Tragedy and Redemption: Iblis in Sufi   Psychology ,   Leyden  :   Brill  ,   1983  .

- Jeremy   Bentham  , Introduction to the Principles of Morals and Legislation (1789), in   J.   St. Mill  , Utilitarianism , ed.   M.   Warnock  ,   Glasgow  :   Collins  ,   1962  .

- Harold    Berman  , Law and  Revolution ,    Cambridge,  MA  :    Harvard  University  Press  , 1983  .

- Allan   Bloom  , The Closing of the American Mind ,   New York  :   Simon & Schuster  ,   1989  .

- Fernand   Braudel  , A History of Civilizations ,   New York  :   Lane  ,   1994 (orig. 1963).

- Allen    Buchanan  , Justice,  Legitimacy,  and  Self-Determination.  Moral  Foundations  for International Law ,   Oxford University Press  ,   2004  .

- Giacomo   Casanova  , History of My Life ,  vol. 1,   Baltimore, MD  :   John Hopkins University Press  ,   1966  .

- Shaohua   Chen and   Martin   Ravallion  , '  How Have the World's Poorest Fared since the Early 1980s?  ' World Bank Research Observer 19  (2),   2004  .

- Amy   Chua  , World on Fire: How Exporting Free Market Democracy Breeds Ethnic Hatred and Global Instability ,   New York  :   Anchor Books  ,   2004  .

- Cicero  , On  Duties ,  eds.    M. T.    Griffi  n  and    E. M.    Atkins  ,    Cambridge  :    Cambridge University Press  ,   1991  .

- Fred    Dallmayr  ,  'Sunyata  East  and  West,  Emptiness  and  Global  Democracy,'  in    F. Dallmayr  , Beyond Orientalism ,   Albany, NY  :   State University of New York Press  ,   1996  .

- René   Descartes  , Œuvres complètes publiés par Charles Adam et Paul Tannery , 12 vols., Paris  :   Cerf  ,   1897  .

- René   Descartes  , The Method, Meditations and Philosophy of Descartes , transl.   J.   Veitch  , Washington and London  :   Dunne  ,   1901  .

- Richard M.   Dorson  , '  The Eclipse of Solar Mythology  ,' Journal of American Folklore 68  , 393  -416,   1955  .

- Michael   Doyle  , Empires ,   Ithaca, NY  :   Cornell University Press  ,   1986  .

- Hal   Draper  , '  The Death of the State in Marx and Engels  ,' Socialist Register vol.   7  ,   281  307,   1970  .

- Peter  F.    Drucker  , The  End  of  Economic  Man.  The  Origins  of  Totalitarianism ,    New Brunswick NJ  : Transactions,   1995 (orig.1939).

- Peter   Drucker  , The Future of Industrial Man ,    New Brunswick NJ  : Transactions,   1995 (orig. 1942).

- Peter F.   Drucker  ,   Isao Nakauchi, Drucker on Asia ,   Oxford  :   Butterworth  ,   1997  .

- Freeman   Dyson  , Infi  nite in All Directions ,   New York  :   Harper  ,   1988  .

- Freeman   Dyson  , The Sun, the Genome, and the Internet ,   New York  :   Oxford University Press  ,   1999  .

- Freeman   Dyson  , '  Our Biotech Future  ,' New York Review of Books ,   2007  .

- Brian   Ellis  , The Philosophy of Nature. A Guide to the New Essentialism ,    Montreal  :   McGillQueen's University Press  ,   2002  .

- Epicurus  , The Extant Remains , ed.   C.  B.   Bailey  ,   Oxford  :   Clarendon  ,   1926  .

- Richard   Feynman  , The Character of Physical Law ,   Cambridge MA  :   MIT Press  ,   1967  .

- Johann  Gottlob    Fichte  , Die  Staatslehre  oder  über  das  Verhältniss  des  Urstaates  zum Vernunftreiche , in   Sämmtliche Werke  ,   hg  .   J. H.   Fichte  , Bd. 4,   Berlin  :   Veit und Co.  , 1845  .

- Norman   Ford  , When Did I Begin? ,   Cambridge  :   Cambridge University Press  ,   1989  . Sigmund   Freud  , 'Vorlesungen zur Einführung in die Psychoanalyse.' Neue Folge, in Freud-Studienausgabe Bd. 1,   Frankfurt  :   Fischer  ,   1969  .

- Francis   Fukuyama  , '  The End of History?  ' The National Interest , Summer   1989  .

- Francis   Fukuyama  , The End of History and the Last Man ,   New York  :   Free Press  ,   1992  . Francis   Fukuyama  , After the Neocons ,   London  :   Profi  le  ,   2007  .

- Jonathan   Glover  , What Sort of People Should There Be?, New York  :   Penguin  ,   1984  .

- Robert    Goodin  ,  'Globalising  Justice,'  in    D.    Held  and    M.    Koenig-Archibugi  eds., Taming Globalization ,   Cambridge  :   Polity  ,   2003  .

- John   Gray  , 'The Moving Target,' New York Review of Books ,   2006  .

- Jü  rgen   Habermas  , Theorie des kommunikativen Handelns ,   Frankfurt  :   Suhrkamp  ,   1981  .

- Jü  rgen   Habermas  , Erkenntnis und Interesse ,   Frankfurt  :   Suhrkamp  ,   1973  .

Jürgen   Habermas  , Die postnationale Konstellation ,   Frankfurt  :   Suhrkamp  ,   1998  .

- Michael    Hardt  and    Antonio    Negri  , Empire ,    Cambridge,  MA  :    Harvard  University Press  ,   2000  .

- E.   Harrison and   S.   Huntington  , eds., Culture Matters ,   New York  : Basic Books,   2000  . Vaclav   Havel  , Or Living in Truth ,   Boston  :   Faber  ,   1987  .

- W.  F.    Hegel  ,  'Grundlinien  der  Philosophie  des  Rechts,'  in  Werke  7,  eds.    E. Moldenhauer and   K. M.   Michel  ,   Frankfurt  :   Suhrkamp  ,   1970  .

- W. F.   Hegel  , Phenomenology of Mind , transl.   J.  B.   Baillie  ,   New Y ork  :   Harper  ,   1967  .

- W. F.   Hegel  , The Philosophy of History , transl.   J.   Sibree  ,   Kitchener, Ontario: Batoche Books  ,   2001  .

- Martin   Heidegger  , Being and Time , transl.   J.   Macquarrie and   E.   Robinson   New York  : Harper  ,   1962  .

- Gustav    Hempel  and    Paul    Oppenheim  ,  'Studies  in  the  Logic  of  Explanation,' Philosophy of Science 15  , 135-75, 1948. Reprinted in   C. G.   Hempel  , Aspects of Scientifi  c Explanation and Other Essays in the Philosophy of Science ,   New York  :   Free Press  ,   1965  .

- Edward   Herman and   Noam   Chomsky  , Manufacturing Consent: The Political Economy of Mass Media ,   New York  :   Pantheon  ,   1988  .

- Thomas   Hobbes  , Leviathan , ed.   C. B.   Macpherson  ,   New York  :   Penguin  ,   1968  .

- Max    Horkheimer  and    Theodor  W.    Adorno  . Dialectic  of  Enlightenment ,  transl.    J. Cumming  ,   New York  :   Continuum  ,   1998 (orig. 1944).

- David   Hume  , A Treatise of Human Nature ,  bk. 3, pt. 2, sec. 2, ed.   Nidditch  ,   Oxford  : Clarendon  ,   1978  .

- Samuel   Huntington  , '  The Clash of Civilizations?  ' Foreign Affairs 72  (3),   22  -49,   1993  .

- Samuel   Huntington  , '  If Not Civilizations, What?  ' Foreign Affairs 72  (5),   186  -94,   1993  .

- Samuel   Huntington  , '  The West: Unique, Not Universal  ,' Foreign Affairs 75  (6),   28  -46, 1996  .

- Ronald   Inglehart  , Culture and Democracy , in   L. E.   Harrison and   S.   Huntington  , eds., Culture Matters ,   New York  : Basic Books,   2000  .

- John Paul   II  , Encyclical letter Fides et ratio, September 14,   1998  .

- Hans    Jonas  , Organismus  und  Freiheit.  Ansätze  zu  einer  philosophischen  Biologie , Göttingen  :   Vandenhoeck  ,   1973  .

- Hans    Jonas  ,  'Der  Gottesbegriff  nach  Auschwitz.  Eine  jüdische  Stimme'  (  1984  ),  in Philosophische  Untersuchungen  und  metaphysische  Vermutungen ,    Frankfurt  :    Suhrkamp  , 1992  .

- Hans    Jonas  , Technik , Medizin und  Ethik . Zur  Praxis  des  Prinzips  Verantwortung , Frankfurt  :   Suhrkamp  ,   1985  .

- Immanuel   Kant  , Kritik der reinen Vernunft , ed.   R.   Schmidt  ,   Hamburg  :   Meiner  ,   1930  .

- Immanuel   Kant  , Metaphysik der Sitten , ed.   Vorländer  ,   Hamburg  :   Meiner  ,   1954  .

- Immanuel   Kant  , Kritik der Urteilskraft , ed. Vorländer,   Hamburg  :   Meiner  ,   1959  .

- Immanuel   Kant  , Critique of Judgment , transl.   J. H.   Bernard  ,   London  :   Macmillan  ,   1914  .

- Immanuel   Kant  , Idea for a Universal History , transl.   L. W.   Beck  , in   I.   Kant  , On History , Indianapolis  :   Bobbs-Merrill  ,   1963  .

- Immanuel    Kant  , Grundlegung  zur  Metaphysik  der  Sitten ,  ed.  Vorländer,    Hamburg  : Meiner  ,   1962  .

- Rudyard   Kipling  , 'The White Man's Burden,' McClure's Magazine 12 (Feb.),   1899  .

- Alexandre   Kojève  , I ntroduction to the Reading of Hegel ,   Ithaca, NY  ,   Cornell University Press  ,   1980  .

- David   Landes  , The Wealth and Poverty of Nations ,   London  :   Little, Brown  ,   1998  . G. W.   Leibniz  , Die philosophischen Schriften , ed.   C. J.   Gerhardt  , vol. 5,   Berlin  :   Schmidt  , 1982  .

- Bernard   Lewis  , 'The Roots of Muslim Rage,' Atlantic Monthly , (Sept.), 47-60, 1990. Benjamin   Libet  , '  Do We Have Free Will?  ' Journal of Consciousness Studies 6 (8-9), 47  -57,   1999  .

- Georg Christoph   Lichtenberg  , Schriften und Briefe , 2 vol., ed.   W.   Promies  ,   Darmstadt  : Wissenschaftliche Buchgesellschaft  ,   1968/1971  .

- John    Locke  , An  Essay  Concerning  Human  Understanding , ed.    Nidditch  , Oxford  : Clarendon  ,   1975  .

- John   Locke  , Two Treatises of Government II, §§ 6 and 27, ed.   P.   Laslett  ,   Cambridge  : Cambridge University Press  ,   1960  .

- Bernard   Mandeville  , The Fable of the Bees: Or, Private Vices, Publick Benefi  ts . ed.   F. B. Kaye  , 2 vols.,   Oxford  :   Oxford University Press  ,   1957 (orig 1924).

- Hans-Peter Martin and   Harald Schumann  , Die Globalisierungsfalle. Der Angriff auf Demokratie und Wohlstand ,   Reinbek bei Hamburg  :   Rowohlt  ,   1998  .

- Karl   Marx  , Capital , vol. 1, transl. S.   Moore and E.   Aveling  ,   Chicago  :   Kerr  ,   1906  .

- Karl   Marx  , 'Formen die der kapitalistischen Produktion vorhergehn,' in Grundrisse der Kritik der politischen Ökonomie ,   Berlin  :   Rohentwurf  ,   1974  .

- Karl   Marx  , Grundrisse , transl.   M.   Nicolaus  ,   New York  :   Penguin  ,   1973  .

- Karl   Marx and   Friedrich   Engels  , Werke ,   Berlin  :   Dietz  ,   1956-1968 (often abbreviated as 'MEW').

- Karl   Marx and   Frederick   Engels  , Selected Works ,   Moscow  :   Progress Publishers  ,   1969  .

- Karl   Marx  and    Frederick    Engels  , Manifesto of  the  Communist  Party ,  transl.    Samuel Moore in Selected Works , vol. 1,   Moscow  :   Progress Publishers  ,   1969  .

- Jessica Tuchman   Mathews  , 'Power Shift,' Foreign Affairs 76, January/February 1997. John Stuart   Mill  , 'On Liberty,' in Utilitarianism , ed.   Mary   Warnock  ,   Glasgow  :   Collins  , 1962  .

- Ludovicus de   Molina  , Liberi Arbitrii cum Gratiae Donis, Divina Praescientia, Providentia, Praedestinatione, et Reprobatione, Concordia ,   Antwerp  :   Trognaesius  ,   1595  .

- Herfried   Münkler  , Empires ,   Cambridge  :   Polity  ,   2007 (German ed., 2005).

- S.   Naipaul  , India. A Million Mutinies Now ,   New York  :   Viking Penguin  ,   1990  .

- Friedrich   Nietzsche  , On the Genealogy of Morals and Ecce Homo , ed.   W.   Kaufman  .   New York  :   Vintage  ,   1989  .

- Friedrich    Nietzsche  , Thus  Spake  Zarathustra ,  transl.    T.    Common  (  1891  ),    Radford  : Wilder  ,   2008  .

- Friedrich   Nietzsche  , Sämtliche Werke. Kritische Studienausgabe ,  ed.    G.    Colli  und    M. Montinari  ,   München  : dtv,   1980  .

- Robert   Nozick  , Anarchy, State, and Utopia ,   New York : Basic Books , 1974  .

- Nussbaum,  Martha, Women  and  Human  Development , Cambridge  : Cambridge University Press  ,   2000  .

- James    Olds and    Peter Milner  , '  Positive  Reinforcement  Produced  by  Electrical Stimulation of Septal Area and Other Regions of Rat Brain  ,' Journal of Comparative Physiological Psychol ogy   47  ,   419  -27, 1954.

- David   Papineau  , 'The Rise of Physicalism,' in   C.   Gillett and   B.   Loewer  , Physicalism and Its Discontents ,   Cambridge  :   Cambridge University Press  ,   2001  .

- Philippe van   Parijs  , Real Freedom for All ,   Oxford  :   Oxford University Press  ,   1995  .

- Philip   Pettit  , '   A Republican Right to Basic Income?  ' Basic Income Studies 2  ,   1  -8, 2007. Plato, Republic ,  transl.    G.  M.  A.    Grube  ,  in Plato,  Republic ,    Indianapolis  :    Hackett  , 1992  .

- Thomas   Pogge  , World Poverty and Human Rights ,   Cambridge  :   Polity  ,   2002  .

- Karl   Polanyi  , The Great Transformation ,   New York  :   Farrar and Rinehart  ,   1944  .

Karl   Popper  , The Open Society ,   London  :   Routledge (Jubilee ed.),   1995  .

Karl   Popper  , Objective Knowledge ,   Oxford  :   Clarendon  ,   1979  .

- Sandra   Pralong, 'Minima Moralia. Is There an Ethics of the Open Society?' in   I.   Jarvie and   S.   Pralong  , eds., Popper's Open Society after Fifty Years ,   London  :   Routledge  ,   1999  .

- Prinz  ,   '  Freiheit oder   Wissenschaft  ,' in   M. v.   Cranach und   K.   Foppa  , eds., Freiheit des Entscheidens und Handelns ,   Heidelberg  :   Asanger  , 86-103, 1996.

Sayyid    Qutb  , Social  Justice  in  Islam ,    Islamic  Publications  International  ,    2001  (orig. 1949).

- Seyyid   Qutb  , Milestones ,   Damascus  : Dar al-Ilm, no date given (orig.   1965  ).

- Tariq   Ramadan  , Western Muslims and the Future of Islam ,   New York  :   Oxford University Press  ,   2004  .

- John   Rawls  , The Law of Peoples ,   Cambridge, MA  :   Harvard University Press  ,   1999  .

- Martin   Rees  , Our Final Hour, A Scientist's Warning: How Terror, Error, and Environmental Disaster Threaten Humankind's Future in This Century On Earth and Beyond ,   New York  : Basic Books,   2003  .

Howard   Robinson  , Perception ,   London  :   Routledge  ,   1994  .

Jacqueline de   Romilly  ,

Olivier   Roy  ,

- The Great Sophists in Periclean Athens ,   Oxford  :   Clarendon  ,   1992  . Globalized Islam ,   New York  :   Columbia University Press  ,   2004  .

- Gilbert   Ryle  , The Concept of Mind ,   London,   Hutchinson  ,   1949  .

- Max   Scheler  , Die Stellung des Menschen im Kosmos , Gesammelte Schriften Bd. 9:   Bern  : Francke  ,   1976  .

- Carl   Schmitt  , The Concept of the Political ,  ed.  and transl.   G.   Schwab  ,   University of Chicago Press  ,   2007  .

- Amartya   Sen  , Development as Freedom ,   Oxford  :   Oxford University Press  ,   1999  .

- Amartya   Sen  , Commodities and Capabilities ,   Delhi  :   Oxford University Press  ,   1999  .

- Anne-Marie    Slaughter  , A  New  World  Order ,    Princeton  :    Princeton  University  Press  , 2005  .

- Adam   Smith  , The Wealth of Nations, ed.   A.   Skinner  ,   New York  :   Penguin  ,   1986 (orig. 1776).

- George   Soros  , The Alchemy of Finance ,   New York  :   John Wiley  ,   1998  .

- George   Soros  , 'Introduction to   W. H.   Newton-Smith  ,' ed., Popper in China ,   London  : Routledge  ,   1992  .

- Richard   Stallman  , Free Software, Free Society ,   Boston  :   GNU Press  ,   2002  .

- Hillel   Steiner  , An Essay on Rights ,   Oxford  :   Blackwell  ,   1994  .

- Hillel   Steiner  , '  Liberty and Equality  ,' Political Studies 29  ,   555  -69,   1981  .

- Hillel    Steiner  , Three  Just  Taxes ,  in    Ph.  van    Parijs  ,  ed., Arguing  for  Basic  Income , London  :   Verso  ,   1992  .

- Ulrich Steinvorth  , Freiheitstheorien der Philosophie der Neuzeit , Darmstadt  : Wissenschaftliche Buchgesellschaft  ,   1994  .

- Ulrich    Steinvorth  , Kritik  der  Kritik  des  Klonens ,  in    J.  S.    Ach  ,    G.    Brudermüller  ,    C. Runtenberg  , Hg., Hello Dolly?, Frankfurt  :   Suhrkamp  ,   1998  .

- Ulrich   Steinvorth  , Gleiche Freiheit ,   Berlin  :   Akademie  ,   1999  .

- Ulrich   Steinvorth  , '  Über den Anfang des menschlichen Individuums  ,' Jahrbuch für Wissenschaft und Ethik 7  ,   165  -78,   2002  .

- Ulrich   Steinvorth  , 'Zur Legitimität des Klonens,' in Körper und Recht: anthropologische Dimensionen der Rechtsphilosophie . ed.   L.   Schwarte  , München: Fink, 2003.

- Ulrich   Steinvorth  , 'On Popper's Concept of an Open Society,' in   I.   Jarvie  ,   K.   Milford  , D.   Miller eds., Karl Popper: A Centenary Assessment , vol. 1,   London  :   Ashgate  ,   2006  .

- Ulrich  Steinvorth  , Ist  die  Enzyclika  Fides  et  Ratio  eine  Herausforderung  an  die  Philosophie ,  in P.    Koslowski  ,    A. M.    Hauk  ,  eds., Die Vernunft des Glaubens und der Glaube der Vernunft ,   München  :   Fink  ,   2007  .

- Ulrich    Steinvorth  , Wittgenstein  über  den  Willen, in  Wilhelm  Lütterfelds  ,  ed.,    Das Sprachspiel   der Freiheit  , Wittgenstein Studies 16, 185-912,   2008  .

- Ulrich   Steinvorth  , Zwei Wurzeln der Allmendebewegungen, eine Politik , in   S.   Helfrich  , ed., Gene, Bytes und Emissionen ,   München  :   Oekom  ,   2009  .

- Ulrich   Steinvorth  , Reason and Will in the Idea for a Universal History and the Groundwork , Festschrift für Volker Gerhardt (forthcoming).

- Thomas Straubhaar  , 'Grundeinkommen: Nachhaltigkeit für den Sozialstaat Deutschland,' HWWI Update ( Mai),   2006  .

- Cass   Sunstein  , republic.com ,   Princeton  :   Princeton University Press  , 2002  .

- Leonard   Swidler  , '  Towards a Universal Declaration of a Global Ethic  ,' Dialogue and Humanism 4 (4),   1993  .

- Charles   Taylor  , Sources of the Self:  The Making of Modern Identity ,    Cambridge MA  : Harvard University Press  ,   1989  .

- Ernst    T ugendhat  , Vorlesungen  zur  Einführung  in  die  sprachanalytische  Philosophie , Frankfurt  :   Suhrkamp  ,   1976  .

- Immanuel   Wallerstein  , World Systems Analysis ,   Durham and London  :   Duke University Press  ,   2004  .

- Max    Weber  , Gesammelte  Aufsätze  zur  Religionssoziologie ,  3  vols.    Tübingen  :    Mohr  , 1920  -1921.

- Max   Weber  , Soziologie, universalgeschichtliche Analysen, Politik ,   Stuttgart  :   Kröner  ,   1973  .

- Max    Weber  , 'Parlament und Regierung im neugeordneten Deutschland,' in Gesammelte politische Schriften ,   Tübingen  :   Mohr  ,   1958  .

- Steven   Weinberg  , The First Three Minutes ,   New York  :   Basic Books,   1977  .

- Steven   Weinberg  , Dreams of a Final Theory ,   New York  :   Vintage  ,   1994  .

- Bernard   Williams  , 'The Macropoulos Case: Refl  ections on the Tedium of Immortality,' in Problems  of  the  Self,  Philosophical  Papers  1956-1972 ,    Cambridge  :    Cambridge University Press  ,   1973  .

- Ludwig   Wittgenstein  , Tractatus logico-philosophicus ,   London  :   Kegan Paul  ,   1922  .

- Ludwig   Wittgenstein  , Philosophical Investigations , transl.   G. E. M.   Anscombe  ,   Oxford  : Blackwell  ,   1953  .
