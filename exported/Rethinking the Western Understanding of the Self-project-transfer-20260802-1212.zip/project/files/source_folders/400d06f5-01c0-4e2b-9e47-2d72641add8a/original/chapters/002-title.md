# Title

## Rethinking the Western Understanding of the Self

Ulrich   Steinvorth CAMBRIDGE UNIVERSITY PRESS Cambridge, New York, Melbourne, Madrid, Cape Town, Singapore, São Paulo, Delhi, Dubai, Tokyo Cambridge University Press The Edinburgh Building, Cambridge CB2 8RU, UK

![](../assets/fig-0001.png)
