# Saved Lookups

## prosopon

Type: highlight
Source: Roman Stoicism, before Roman Epicureanism


## prosopon

Type: question
Source: Roman Stoicism, before Roman Epicureanism

- Web search: https://research-portal.uu.nl/ws/files/278388932/Phersu_Prosopon_Persona_final_version_.pdf
- Web search: https://link.springer.com/article/10.1007/s11196-021-09838-6
- Web search: https://www.perseus.tufts.edu/hopper/text?doc=Perseus%3Atext%3A1999.04.0057%3Aentry%3Dpro%2Fswpon&toc=Perseus%3Atext%3A1999.04.0057%3Aalphabetic+letter%3D*p%3Aentry+group%3D169
- Web search: https://languagelore.net/2015/03/02/the-pathos-of-everyday-life-5-persona-mask-3/
- Web search: https://en.wikisource.org/wiki/Catholic_Encyclopedia_(1913)/Person
- AI tutor: ollama deepseek-v4-pro

## 도시국가가 쇠퇴하고 비관주의가 퍼지자, 키니코스 학파(Cynics)와 스토아 학파(Stoics)는 내면의 자원을 강조하며 개인주의로 전환했고

Type: highlight
Source: Roman Stoicism, before Roman Epicureanism


## 도시국가(polis)가 쇠퇴하면서 시민들은 더 이상 공동체 안에서 조화로운 역할을 수행하는 것만으로는 삶의 의미를 찾기 어려워졌습니다.

Type: highlight
Source: Roman Stoicism, before Roman Epicureanism


## 결국 라틴어 페르소나(persona)가 오늘날의 ‘사람(person)’이라는 뜻을 획득한 것은, 바로 이 개인주의적 전회의 산물입니다.

Type: question
Source: Roman Stoicism, before Roman Epicureanism

- AI tutor: ollama deepseek-v4-pro

## 반면 로마 철학자들은 이러한 일반적 접근에 개인의 고유한 성격과 사람들을 구별짓는 것, 그리고 생물학·행동을 넘어 인간의 주관성(subjectivity)에 대한 관심을 더했습니다.

Type: highlight
Source: Roman Stoicism, before Roman Epicureanism
