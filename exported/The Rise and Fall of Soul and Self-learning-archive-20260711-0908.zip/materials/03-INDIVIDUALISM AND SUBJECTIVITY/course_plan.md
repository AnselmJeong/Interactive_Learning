# INDIVIDUALISM AND SUBJECTIVITY
Source-grounded adaptive learning material

Estimated time: 20 minutes

## Modules

1. **Individualism and Subjectivity**
   원문을 직접 읽지 않아도 INDIVIDUALISM AND SUBJECTIVITY의 핵심 주장과 긴장을 설명할 수 있다.
2. **Roman Stoicism**
   원문을 직접 읽지 않아도 Roman Stoicism의 핵심 주장과 긴장을 설명할 수 있다.
3. **Roman Epicureanism**
   원문을 직접 읽지 않아도 Roman Epicureanism의 핵심 주장과 긴장을 설명할 수 있다.
4. **Neoplatonism**
   원문을 직접 읽지 않아도 Neoplatonism의 핵심 주장과 긴장을 설명할 수 있다.
