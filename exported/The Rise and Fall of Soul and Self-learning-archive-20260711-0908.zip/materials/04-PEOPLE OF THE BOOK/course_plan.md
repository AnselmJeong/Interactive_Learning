# PEOPLE OF THE BOOK
Source-grounded adaptive learning material

Estimated time: 30 minutes

## Modules

1. **People of the Book**
   원문을 직접 읽지 않아도 PEOPLE OF THE BOOK의 핵심 주장과 긴장을 설명할 수 있다.
2. **Judaism**
   원문을 직접 읽지 않아도 Judaism의 핵심 주장과 긴장을 설명할 수 있다.
3. **Christianity**
   원문을 직접 읽지 않아도 Christianity의 핵심 주장과 긴장을 설명할 수 있다.
4. **And Again**
   원문을 직접 읽지 않아도 And again:의 핵심 주장과 긴장을 설명할 수 있다.
5. **Islam**
   원문을 직접 읽지 않아도 Islam의 핵심 주장과 긴장을 설명할 수 있다.
6. **Monotheism and Western Conceptions of Self**
   원문을 직접 읽지 않아도 Monotheism and Western Conceptions of Self의 핵심 주장과 긴장을 설명할 수 있다.
