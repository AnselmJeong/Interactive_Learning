# Care of the Soul
Source-grounded adaptive learning material

Estimated time: 25 minutes

## Modules

1. **VII › Care of the Soul**
   원문을 직접 읽지 않아도 VII > CARE OF THE SOUL의 핵심 주장과 긴장을 설명할 수 있다.
2. **VII › Platonism**
   원문을 직접 읽지 않아도 VII > Platonism의 핵심 주장과 긴장을 설명할 수 있다.
3. **VII › Aristotelianism**
   원문을 직접 읽지 않아도 VII > Aristotelianism의 핵심 주장과 긴장을 설명할 수 있다.
4. **VII › Late Renaissance Natural Philosophy**
   원문을 직접 읽지 않아도 VII > Late Renaissance Natural Philosophy의 핵심 주장과 긴장을 설명할 수 있다.
5. **VII › the Growth of Subjectivity**
   원문을 직접 읽지 않아도 VII > The Growth of Subjectivity의 핵심 주장과 긴장을 설명할 수 있다.
