# Saved Lookups

## 영혼을 단순한 생명 원리가 아니라, 윤리적·종교적 완성의 대상으로 격상

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 정화 의례를 통해 육체의 굴레에서 벗어나 신들과 영원히 함께할 수 있다고 가르쳤습니다

Type: question
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self

- AI tutor: ollama deepseek-v4-pro

## 반면 영웅들은 신과 같은 존재가 되어 더 강력한 방식으로 살아남지만, 이 생존은 영웅 자신보다 살아 있는 공동체를 위한 것이었습니다.

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 살아 있는 동안의 정체성과 의식이 사라진 존재는 '살 가치가 없는 삶'으로 여겨졌고, 그래서 아무도 단순한 생존을 위해 영웅이 되려 하지 않았습니다.

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 핀다로스(Pindar)의 시와 소포클레스(Sophocles)의 비극

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 죽은 영혼이 살아생전 어떻게 살았는지에 따라 더 큰 영향을 받는 도덕적 관념으로 점차 이동

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 대체로 감정과 욕구를 지닌 신체 기능으로 이해되었습니다

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 프시케를 더 영적인 용어로 생각하기 시작했습니다.

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 프시케

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## Pindar

Type: lookup
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self

핀다로스는 고대 그리스의 서정시인으로, 그의 작품은 동시대 다른 시인들에 비해 가장 잘 보존되어 있지만, 그 시의 난해함과 독특함으로 인해 일반 대중에게는 널리 읽히지 않습니다. 그의 시는 숭고한 아름다움과 풍요로운 언어로 찬사를 받았지만, 동시에 그 복잡성 때문에 아테네의 희극 시인 에우폴리스는 대중이 그의 '우아한 학식'을 꺼려 침묵 속에 묻혔다고 평하기도 했습니다.

핀다로스 시의 난해함은 단순히 개인적인 스타일의 문제가 아니었습니다. 19세기 말 그의 경쟁자였던 바킬리데스의 시가 발견되면서, 핀다로스 작품의 독특함이 개인의 기벽이 아니라 고대 그리스 서정시 장르 자체의 공통된 특징이었음이 밝혀졌습니다. 그럼에도 불구하고, 그의 시는 여전히 학자들의 감탄을 자아내면서도 일반 독자들에게는 쉽게 다가가기 어려운 작품으로 남아 있습니다.

- Wikipedia (en): https://en.wikipedia.org/wiki/Pindar
- AI Korean summarizer: ollama deepseek-v4-pro

## 오이디푸스의 경우 고통과 속죄의 과정을 거친 도덕적 정화가 강조됩니다.

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 프시케를 감정과 욕구를 지닌 신체 기능

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 후기 사상가들은 프시케를 몸을 떠나 독립적으로 존재할 수 있는 영적인 실체로 생각

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 피타고라스(Pythagoras, 기원전 530년경 활동)와 엠페도클레스(Empedocles, 기원전 450년경 활동)는 자아에 관심을 가진 최초의 철학자

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 윤회(transmigration)와 전생 기억

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 영혼이 몸을 떠나 여행하고, 질병을 고치며, 죽은 자를 소생시키는 능력을 지녔다고 믿어졌습니다

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 삼분 영혼설

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 그리스 샤머니즘

Type: question
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self

- AI tutor: ollama deepseek-v4-pro

## 그리스 샤머니즘은 공동체를 위한 실용적 목적(치유, 예언)을 띠었고, 현대의 명상은 주로 개인의 내적 평화나 자기 이해에 초점을 둡니다

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 불순한 영혼은 신들 곁에 머물며 다시 인간, 동물, 혹은 더 낮은 존재로 윤회(incarnation)를 기다립니다.

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 궁극적으로 모든 영혼은 우주적 신(universal deity)과 하나가 됩니다.

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 육체가 영혼의 감옥이 아니라 일시적인 거처가 되며, 삶의 목표는 영혼의 본래 순수성을 회복하는 것이 됩니다

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 명상·의례로 순수성 회복 가능

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 도, 이 합리적 전통의 기원이 마법과 주술의 샤머니즘에 있을 수 있다는 점을 지적합니다

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 피타고라스와 엠페도클레스

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 아우구스티누스를 통해 기독교 신학에 편입

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 기독교를 통해 세속과 종교를 망라한 서양 문명 전체의 사고방식 형성

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 반면 지혜는 자기 인식에서 오며, 깨어 있는 사람들은 공통된 하나의 세계를 공유하고, 영혼의 무한한 깊이, 즉 로고스를 발견합니다. 죽음 후에는 어리석은 자의 습한 영혼은 물로 돌아가고, 지혜로운 자의 건조한 영혼은 우주의 불에 합류합니다.

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 제대로 사는 것은 영혼을 건조하게 만듭니다.

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 공통된 세계를 공유

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 사적인 망상에서 벗어나 모두가 공유하는 로고스의 질서에 참여

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 진실이 개인의 주관적 확신이 아니라 상호주관적이고 합리적인 공통 기반 위에 서야 한다는 통찰

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 반면 '건조한 영혼'은 자기 인식을 통해 보편적 로고스를 깨닫고, 깨어 있는 사람들이 공유하는 하나의 세계에 참여하는 상태입니다

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 자기 인식이 깊어질수록 개인을 넘어선 보편적 원리와 접촉함

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## '사회적 마음챙김'이나 '공감적 소통'

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 로고스는 모든 사람에게 동일하므로, 깨어 있는 사람들은 공통된 세계를 공유한다.

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 따라서 진정한 지혜는 개인적 견해가 아니라 로고스에 참여하는 것이다.

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 헤라클레이토스(Heraclitus)

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 아우구스티누스를 통해 기독교 신학에 편입

Type: question
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self

- AI tutor: ollama deepseek-v4-pro

## impermanence

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 이는 모든 것이 영원히 변하며 고정된 실체란 없다

Type: highlight
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self


## 불변하는 본질은 없다는 것이 헤라클레이토스의 결론

Type: question
Source: FROM MYTH TO SCIENCE, before [ 12 ] the rise and fall of soul and self

- AI tutor: ollama deepseek-v4-pro

## 이는 동일성이 실체의 불변이 아니라 변화하는 부분들 사이의 관계에 기초할 수 있다는 관계적 관점의 단초를 제시합니다.

Type: highlight
Source: [ 12 ] the rise and fall of soul and self, before Platonism


## 그 감각은 기억의 연속성과 서사적 통일성에서 비롯될 수 있습니다.

Type: highlight
Source: [ 12 ] the rise and fall of soul and self, before Platonism


## 디오티마

Type: highlight
Source: [ 12 ] the rise and fall of soul and self, before Platonism


## 디오티마

Type: lookup
Source: [ 12 ] the rise and fall of soul and self, before Platonism

디오티마는 플라톤의 대화편 《향연》에 등장하는 여성 철학자로, 소크라테스에게 에로스(사랑)의 본질을 가르친 인물입니다. 그녀는 사랑이 단순한 육체적 욕망이 아니라, 아름다운 육체에서 시작해 영혼의 아름다움, 나아가 지혜와 진리 같은 절대적 아름다움으로 상승하는 단계적 과정이라고 설명합니다. 이 개념은 플라톤적 사랑의 핵심으로, 디오티마의 가르침은 서양 철학에서 사랑과 미에 대한 이상주의적 이해의 기초가 되었습니다.

디오티마가 실존 인물인지는 불분명하며, 플라톤이 창조한 문학적 장치로 보는 견해가 많습니다. 그녀의 이름은 '제우스를 공경하는 여인'이라는 뜻으로, 《향연》에서 소크라테스가 그녀를 만티네아 출신의 예언자로 소개하지만, 역사적 기록은 전혀 남아 있지 않습니다.

- Wikipedia (en): https://en.wikipedia.org/wiki/Diotima
- AI Korean summarizer: ollama deepseek-v4-pro

## 이러한 관계적 관점(relational view)은 오늘날 개인 정체성 이론가들이 거의 대부분 지지하는 입장이며, 이것이 주류가 되기 위해서는 먼저 플라톤의 불변하는 영혼 개념이 극복되어야 했습니다.

Type: highlight
Source: [ 12 ] the rise and fall of soul and self, before Platonism


## 인간이 영원한 형상을 파악할 때 순간적으로 불멸에 참여한다고 말합니다.

Type: highlight
Source: [ 12 ] the rise and fall of soul and self, before Platonism


## 『파이돈』에서는 초점을 영혼의 불멸로 옮겨, 육체적 죽음 이후에도 지속되는 유일한 부분이 영혼

Type: highlight
Source: [ 12 ] the rise and fall of soul and self, before Platonism


## 결국 영혼은 변하지 않는 신적 상태에 참여한다.

Type: question
Source: [ 12 ] the rise and fall of soul and self, before Platonism

- AI tutor: ollama deepseek-v4-pro

## 자신의 영혼을 돌보는 것

Type: question
Source: Platonism, before Aristotelianism

- AI tutor: ollama deepseek-v4-pro

## 기원전 5세기

Type: highlight
Source: Platonism, before Aristotelianism


## 13세기

Type: highlight
Source: Platonism, before Aristotelianism


## 17세기

Type: highlight
Source: Platonism, before Aristotelianism


## 그럼에도 이들의 논증은 서양에서 영혼 불멸을 명시적으로 의심한 최초의 사례로 기록됩니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 진리를 추구하는 태도

Type: highlight
Source: Platonism, before Aristotelianism


## 영혼이 부분으로 구성되지 않은 '단순한' 실체라면 분해될 수 없으므로 불멸한다는 결론에 도달합니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 영혼이 단순하다면(부분이 없다면), 분해될 수 없으므로 소멸하지 않는다.

Type: highlight
Source: Platonism, before Aristotelianism


## 플라톤은 영혼이 인간의 본질이며, 단순한 실체라고 주장한다.

Type: highlight
Source: Platonism, before Aristotelianism


## 영혼의 단순성은 살아 있는 동안의 변화에도 불구하고 인격적 동일성을 보장하며, 결국 영혼은 불멸한다.

Type: highlight
Source: Platonism, before Aristotelianism


## 감정이나 성격 같은 것은 영혼이 육체와 결합하면서 생기는 부수적 현상으로 간주했을 가능성이 큽니다. 그러나 이렇게 되면 우리가 '나'라고 느끼는 구체적인 심리적 삶의 대부분이 본질적인 자아에서 배제되는 문제가 생깁니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 플라톤은 영혼이 비물질적이고 단순하여 부분이 없다고 주장함으로써, 매개체가 반드시 물질적이어야 한다는 가정을 깨뜨렸다

Type: highlight
Source: Platonism, before Aristotelianism


## 매개체 없이도 정보나 패턴으로 생존할 수 있다고 본다면, 영혼의 불멸은 물질적 담지자가 아니라 관계나 기억의 지속성으로 재정의될 수 있습니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 그럼에도 이 '사변적 모험(speculative derring-do)'은 이후 서양 철학에서 영혼을 물질로 환원하지 않는 전통의 출발점이 되었습니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 물질주의에 대한 급진적 대안을 '제안'

Type: highlight
Source: Platonism, before Aristotelianism


## 『파이돈』에 대한 가장 직선적인 해석이 영혼이 부분이 없을 뿐만 아니라 연장되지 않았다는 것이라고 말합니다. 이 해석은 2세기 신플라톤주의자들과 17세기 데카르트에게도 이어졌습니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 3세기 플로티누스는 이 생각을 발전시켜 우리 각자가 비물질적이고 연장되지 않은 영혼을 본질로 가진다는 관점을 만들었고, 이것이 가장 영향력 있는 버전이 되었습니다.

Type: highlight
Source: Platonism, before Aristotelianism


## '단순하고 신들과 유사하다'

Type: highlight
Source: Platonism, before Aristotelianism


## 모든 존재의 근원인 '일자(the One)'로부터 영혼이 유출(emanation)된다는 체계를 세웠다.

Type: highlight
Source: Platonism, before Aristotelianism


## 완전히 비물질적이고 연장되지 않으며, 본질적으로 신적 영역에 속한다.

Type: highlight
Source: Platonism, before Aristotelianism


## 영혼은 육체에 깃들어 있지만, 그 본성은 물질 세계를 초월해 있다.

Type: highlight
Source: Platonism, before Aristotelianism


## 죽음은 영혼이 본래의 신적 고향으로 돌아가는 과정이다.

Type: highlight
Source: Platonism, before Aristotelianism


## 물질 세계와 영혼의 세계를 엄격히 구분하는 이원론의 토대

Type: highlight
Source: Platonism, before Aristotelianism


## 데카르트가 '생각하는 실체(res cogitans)'를 연장되지 않은 실체로 정의한 것은, 플로티누스를 거쳐 전해진 이 플라톤 해석의 직접적인 계승

Type: highlight
Source: Platonism, before Aristotelianism


## 플라톤은 영혼이 단순히 외부 요인으로 인해 불멸하는 것이 아니라, 그 자체의 본성으로 인해 불멸하기를 원했습니다

Type: highlight
Source: Platonism, before Aristotelianism


## 나누어질 수 있는 것은 잠재적으로 분해될 수 있고, 따라서 소멸 가능하다(corruptible)

Type: highlight
Source: Platonism, before Aristotelianism


## 필연적 불멸을 위해서는 소멸 가능성 자체가 제거되어야 하므로, 자아는 연장되지 않아야(unextended) 한다.

Type: highlight
Source: Platonism, before Aristotelianism


## 그러나 동시에 영혼은 인지, 욕구, 결정, 고통, 쾌락 등 온갖 심리적 복잡성과 변화를 담는 자연스러운 매개체로도 그려집니다

Type: highlight
Source: Platonism, before Aristotelianism


## 영혼은 육체에 생명을 불어넣는 생명 원리로서의 본질적 기능 또한 지닙니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 플라톤은 아마도 영혼의 '상위 부분'은 순수하고 불변하지만, 육체와 결합된 동안에는 하위 기능들이 덧붙여진다고 보았을 것입니다. 이 긴장은 후에 『국가』에서 영혼 삼분설로 발전하며, 순수한 이성 부분과 욕구 부분이 갈등하는 구조로 해소됩니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 『파이돈』의 영혼은 불변하는 형상들과 닮아야만 영원한 진리를 인식할 수 있지만, 동시에 우리의 도덕적 책임과 개인적 정체성을 설명하려면 삶의 경험에 영향받고 변화할 수 있어야 합니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 삼분설

Type: highlight
Source: Platonism, before Aristotelianism


## 샤먼이 황홀경을 통해 얻는 지식은 신비적이고 비전(秘傳)적인 '오컬트 지식(occult knowledge)'인 반면, 철학자가 정신 집중을 통해 상기하는 것은 필연적 진리, 즉 형상(Forms)에 대한 지식입니다

Type: highlight
Source: Platonism, before Aristotelianism


## occult knowledge

Type: lookup
Source: Platonism, before Aristotelianism

오컬트(occult)는 조직화된 종교나 과학의 범주 밖에 있는 비의적(esoteric)이거나 초자연적인 믿음과 실천을 통칭하는 분류입니다. 이 용어의 핵심은 라틴어 '오쿨투스(occultus, 숨겨진)'에서 유래한 '숨겨진' 또는 '비밀스러운' 힘의 작용을 전제한다는 점이며, 여기에는 마법(magic)이나 신비주의(mysticism) 같은 현상이 포함됩니다. 단순한 미신과 달리, 오컬트는 특정한 지식 체계나 수행을 통해 접근할 수 있는 숨겨진 실재를 탐구한다는 점에서 중요합니다.

오컬트라는 용어는 초감각적 지각(extra-sensory perception)이나 초심리학(parapsychology)처럼 현대 과학의 경계에 있는 초자연적 개념까지 포괄하기도 합니다. 이는 오컬트가 단순히 고대의 주술적 행위에만 국한되지 않고, 과학적 방법으로는 완전히 설명되지 않는 정신적·초자연적 현상에 대한 탐구까지 포함하는 넓은 범주임을 보여줍니다.

- Wikipedia (en): https://en.wikipedia.org/wiki/Occult
- AI Korean summarizer: ollama deepseek-v4-pro

## 이성적(rational), 기개적(spirited), 욕구적(appetitive)

Type: highlight
Source: Platonism, before Aristotelianism


## 이성이 기개나 욕구 대신 지배할 때 영혼은 조화로워지며, 이성은 자기 이익을 추구하지만 동시에 타인의 복지를 증진하라고 명령하기 때문에, 자기 이익과 도덕이 일치하게 됩니다

Type: highlight
Source: Platonism, before Aristotelianism


## 이성이 목표를 설정하고 기개가 그 실행을 돕고 욕구는 필요한 만큼만 충족된다.

Type: highlight
Source: Platonism, before Aristotelianism


## faculty psychology

Type: lookup
Source: Platonism, before Aristotelianism

Faculty psychology(능력 심리학)은 마음을 여러 개의 독립된 능력(faculties)으로 나누고, 판단·기억·주의·지각 같은 각각의 정신 작용이 특정 능력에 할당되어 있다고 보는 관점이다. 이 이론은 인간이 선천적으로 분리된 정신 기능들을 가지고 태어난다고 주장했기 때문에, 근대 심리학이 경험과 학습을 통한 통합적 발달을 강조하기 전까지 심리학과 교육학에서 중요한 설명 틀로 작용했다.

토머스 리드(Thomas Reid)는 마음이 43개 이상의 능력으로 구성되어 있으며, 이 능력들이 하나의 전체로서 함께 작동한다고 보았다. 예를 들어 말을 할 수 있는 것은 ‘언어 능력(faculty of speech)’이, 생각할 수 있는 것은 ‘사고 능력(faculty of thought)’이 있기 때문이라는 식으로 설명했는데, 이는 복잡한 정신 과정을 지나치게 단순화하고 능력들 간의 상호작용을 간과했다는 비판을 받기도 했다.

- Wikipedia (en): https://en.wikipedia.org/wiki/Faculty_psychology
- AI Korean summarizer: ollama deepseek-v4-pro

## functional psychology

Type: lookup
Source: Platonism, before Aristotelianism

기능주의 심리학은 인간 행동의 구조보다 그 기능과 적응적 목적에 초점을 맞춘 심리학 학파로, 다윈의 진화론에서 직접적인 영향을 받아 행동이 어떻게 생존과 적응에 기여하는지를 탐구했습니다.

이 학파는 에드워드 티치너(Edward Titchener)의 구성주의 심리학에 반대하며 등장했는데, 구성주의가 의식의 내용을 분석하는 데 집중한 반면, 기능주의는 에드워드 손다이크(Edward Thorndike)의 시행착오 학습 연구처럼 행동의 실용적 측면과 생물학적 과정을 중시하며 내성법(introspection)을 거부했습니다.

- Wikipedia (en): https://en.wikipedia.org/wiki/Functional_psychology
- AI Korean summarizer: ollama deepseek-v4-pro

## modular theories

Type: question
Source: Platonism, before Aristotelianism

- AI tutor: ollama deepseek-v4-pro

## 영혼의 구조와 그 부분들 간의 역학을 분석하는 최초의 경험적 심리학

Type: highlight
Source: Platonism, before Aristotelianism


## 플로티노스는 『티마이오스』의 창조 이야기를 일자(一者)로부터의 유출(emanation) 이론으로 재해석

Type: highlight
Source: Platonism, before Aristotelianism


## 아우구스티누스는 『티마이오스』의 창조 신화를 성경의 창세기와 조화시키려 했습니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 마르실리오 피치노는 『티마이오스』를 라틴어로 번역하고 주석을 달아, 우주를 살아 있는 유기체로 보는 관점을 부활시켰습니다.

Type: highlight
Source: Platonism, before Aristotelianism


## '우주는 수학적 조화로 이루어졌다'는 생각은 근대 물리학의 기초가 되었습니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 신적인 것을 더럽히지 않으려는 염려 때문에, 반신들은 불멸의 부분을 목 위에, 필멸의 부분을 목 아래에 두고 목을 경계로 삼았습니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 격정 내에서도 기개(명예·분노)와 욕구(생리적 충동)가 분리되어야 함을 시사합니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 이성(상위)과 격정(하위) 사이의 위계

Type: highlight
Source: Platonism, before Aristotelianism


## 우리가 어떻게 형상(Forms)에 대한 지식을 갖게 되는지를 설명하기 위해서

Type: highlight
Source: Platonism, before Aristotelianism


## 각 개인이 경험하는 의식의 통일성, 즉 여러 감각과 생각이 하나의 '나'로 묶이는 현상을 설명하기 위해서

Type: highlight
Source: Platonism, before Aristotelianism


## 하나의 통일된 의식

Type: highlight
Source: Platonism, before Aristotelianism


## binding problem

Type: highlight
Source: Platonism, before Aristotelianism


## 플라톤이 영혼의 불멸성과 순수성을 지키기 위해 비물질적 실체를 상정했지만, 동시에 인간 행동을 설명하기 위해 세속적 영혼을 추가하면서 이원론의 긴장이 시작되었음을 보았습니다

Type: highlight
Source: Platonism, before Aristotelianism


## 플라톤에게 완전히 실재하는 것은 비물질적이고 이성적인 것뿐이며, 물질적 세계는 그것에 '참여(participation)'함으로써 파생적 실재성을 얻을 뿐입니다.

Type: highlight
Source: Platonism, before Aristotelianism


## 플라톤이 영혼을 이성적 상위 부분과 육체적·짐승 같은 하위 부분으로 나눈 것이 무의식 개념의 궁극적 이론적 기원일 수 있다고 주장

Type: highlight
Source: Platonism, before Aristotelianism


## 아우구스티누스(Augustine)를 거쳐 참된 자아와 거짓 자아의 구분

Type: question
Source: Platonism, before Aristotelianism

- AI tutor: ollama deepseek-v4-pro

## ‘자기기만(self-deception)

Type: highlight
Source: Platonism, before Aristotelianism


## 특히 12세기에 ‘자기기만’ 개념이 등장한 것은, 하위 충동이 단지 이성에 반항하는 것이 아니라 스스로를 속일 수 있는 어떤 내적 기만자로 개념화되기 시작했음을 뜻합니다

Type: highlight
Source: Platonism, before Aristotelianism


## 플라톤에게 하위 영혼은 통제되어야 할 대상이었지만, 프로이트에게 무의식은 인정하고 통합해야 할 ‘나’의 일부였습니다

Type: highlight
Source: Platonism, before Aristotelianism


## 영혼은 자기 자신을 움직이는 것(자기 운동자)으로 정의된다.

Type: highlight
Source: Platonism, before Aristotelianism


## 항상 운동하는 것은 불멸한다. 따라서 모든 영혼은 불멸한다.

Type: highlight
Source: Platonism, before Aristotelianism


## 다른 것에 의해 움직이는 것은 운동을 멈출 수 있고, 생명을 멈출 수 있으므로 영혼이 없다

Type: highlight
Source: Platonism, before Aristotelianism


## 자기 운동자만이 자신의 본성을 버리지 않으므로, 오직 자기 운동자만이 불멸이다.

Type: highlight
Source: Platonism, before Aristotelianism


## 식물적·동물적 영혼은 몸과 함께 소멸; 오직 능동적 이성만이 불멸

Type: highlight
Source: Platonism, before Aristotelianism


## 몸의 형상(엔텔레케이아)

Type: highlight
Source: Platonism, before Aristotelianism


## 엔텔레케이아

Type: question
Source: Platonism, before Aristotelianism

- AI tutor: ollama deepseek-v4-pro

## 초기에는 플라톤처럼 이성적 부분(누스)이 불멸한다고 생각했지만, 후기 저작 『영혼론』(De anima) 등에서는 그 생존에 대해 모호한 입장을 취했습니다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 존재에는 등급이 있어 무기물에서 식물, 동물, 인간을 거쳐 순수 형상인 부동의 원동자(Unmoved Mover)에 이르기까지 실재성의 정도가 다릅니다

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 인간 – 이성(누스)을 지닌 이성적 영혼

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 부동의 원동자가 예외적으로 비물질적

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 후대 기독교 신학자들은 이 부동의 원동자를 신과 동일시하며, 아리스토텔레스의 형이상학을 유일신교 교리와 결합시켰다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 누스가 개별적 인격을 유지하는지, 아니면 모든 인간이 이성적 사고를 할 때 공유하는 하나의 실체인지는 불분명합니다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 결국 아리스토텔레스의 권위가 '신적 계시(Divine Revelation)에 거의 버금가는' 수준이었기에, 그의 영혼론을 어떻게 해석하느냐는 단순한 학문적 논쟁이 아니라 정통 신앙을 수호하는 문제로 비화되었다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 토마스 아퀴나스(Thomas Aquinas) 등 스콜라 철학자들은 아리스토텔레스의 형이상학과 자연철학을 기독교 교리와 종합하려 했고, 이 과정에서 그의 권위는 '철학자(The Philosopher)'로 불릴 만큼 절대적이 되었다.

Type: question
Source: Aristotelianism, before Materialistic Atomism

- Web search: https://www.academia.edu/22668008/Antiplatonism_in_the_Renaissance_and_the_middle_ages
- Web search: https://plato.stanford.edu/archives/spr2026/entries/medieval-philosophy/
- Web search: https://plato.stanford.edu/ARCHIVES/WIN2009/ENTRIES/medieval-philosophy/
- Web search: https://www.rep.routledge.com/article/B008
- Web search: https://www.rep.routledge.com/articles/thematic/aristotelianism-medieval/v-1/sections/the-thirteenth-century
- AI tutor: ollama deepseek-v4-pro

## monopsychism

Type: question
Source: Aristotelianism, before Materialistic Atomism

- Web search: https://plato.stanford.edu/eNtRIeS/ibn-rushd/
- Web search: https://iep.utm.edu/ibn-rushd-averroes/
- Web search: https://plato.stanford.edu/entries/ibn-rushd-natural/
- Web search: https://epublications.marquette.edu/phil_fac/250
- Web search: https://plato.stanford.edu/entries/arabic-islamic-influence/
- AI tutor: ollama deepseek-v4-pro

## 누스를 제외하면 영혼의 모든 부분이 몸과 동시에 생겨나고 분리될 수 없으며, 따라서 몸이 소멸할 때 함께 소멸한다고 봅니다

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 그는 『영혼론』에서 지성이 '생겨나지만 소멸되지 않는 실체인 듯 보인다'고 덧붙여, 이 그림을 흐려 놓았습니다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 능동 지성은 분리되어 있고, 섞이지 않으며, 소멸되지 않고, 그 본질은 순수한 활동입니다

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 이성적 영혼은 내부에서 생성될 수 없고 '외부로부터 올 수밖에 없으며, 오직 그것만이 신적'이라고 단언합니다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 능동 지성은 신적인 빛처럼 모든 인간에게 공통된 사유의 조건으로 남습니다.

Type: question
Source: Aristotelianism, before Materialistic Atomism

- AI tutor: ollama deepseek-v4-pro

## 따라서 개인의 경험과 인격을 구성하는 기억은 죽음 이후에 존속하지 않는다는 결론이 자연스럽게 따라붙습니다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## Alexander of Aphrodisias

Type: lookup
Source: Aristotelianism, before Materialistic Atomism

아프로디시아스의 알렉산드로스(Alexander of Aphrodisias)는 서기 3세기 초 아테네에서 활동한 고대 그리스 철학자로, 아리스토텔레스의 저작에 대한 가장 권위 있는 주석가로 평가받으며 후대에 단순히 '주석가'라는 칭호로 불릴 만큼 큰 영향력을 행사했습니다. 그의 방대한 주석 작업은 아리스토텔레스 철학의 정수를 보존하고 체계화하여 중세 이슬람 철학과 유럽 스콜라 철학에 지대한 영향을 미쳤습니다.

그는 단순한 해설을 넘어 자신만의 독창적인 철학을 전개했는데, 특히 《운명에 관하여》에서 스토아 학파의 결정론을 반박하고 인간의 자유 의지를 옹호한 점과, 《영혼에 관하여》에서 인간의 지성을 신체와 분리된 불멸의 실체가 아닌 신체와 결합하여 기능하는 필멸의 능력으로 설명한 점이 주목할 만합니다.

- Wikipedia (en): https://en.wikipedia.org/wiki/Alexander_of_Aphrodisias
- AI Korean summarizer: ollama deepseek-v4-pro

## 사후에 능동 지성만이 불멸한다면, 개인의 기억과 인격은 사라지고 비인격적인 신적 지성만 남게 된다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 소크라테스가 하나의 개별자인 것은 그에게 고유한 질료가 있기 때문입니다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 동시에 인간의 본질이 개별자를 초월하는 보편적 실재임을 암시합니다

Type: question
Source: Aristotelianism, before Materialistic Atomism

- Web search: https://plato.stanford.edu/ENTRIES/aristotle-metaphysics/
- Web search: https://plato.stanford.edu/entries/aristotle-categories/
- Web search: https://en.wikipedia.org/wiki/Aristotle's_theory_of_universals
- Web search: https://dergipark.org.tr/en/pub/iufad/article/1012750
- Web search: https://doi.org/10.1093/acprof:oso/9780198722717.003.0004
- AI tutor: ollama deepseek-v4-pro

## 『생성과 소멸에 관하여』에서 인간과 동물이 왜 동일한 개체로 다시 태어나지 않는지 묻고, 실체가 불멸인 것과 소멸 가능한 것을 구분하여 답합니다

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 따라서 이 구분은 그의 형이상학적 원리, 즉 질료가 개체화의 원리라는 전제에서 필연적으로 도출되는 결론입니다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 초기 교부들(예: 오리게네스)은 부활을 영적인 몸의 회복으로 보는 경향이 있어, 육체적 동일성보다는 형상의 연속성을 강조했다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 13세기 스콜라 철학자들은 이 긴장을 해소하려 아리스토텔레스의 질료 개체화 원리와 부활체의 동일성을 조화시키려 시도했지만, 완전한 해결은 어려웠다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 육체의 방해에서 벗어나 영원한 진리를 발견할 수 있고, 죽은 자들과 대화하는 기쁨을 누릴 수 있다고 보았기 때문입니다

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 소크라테스는 사형을 앞두고 죽음이 영혼의 이주라면, 저승에서 위대한 시인·영웅들과 대화할 수 있으리라 기대했습니다

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 이성의 완성은 현세의 관조적 삶에서 가능하다고 보았기 때문에, 사후 생존의 중요성은 상대적으로 덜 부각되었을 것입니다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 능동 지성만이 신과 모든 인간에게 동일하게 존재하여 육체의 죽음 이후에도 살아남는다고 주장했습니다

Type: question
Source: Aristotelianism, before Materialistic Atomism

- AI tutor: ollama deepseek-v4-pro

## 모든 인간이 하나의 동일한 누스를 공유한다.

Type: question
Source: Aristotelianism, before Materialistic Atomism

- Web search: https://en.wikipedia.org/wiki/Active_intellect
- Web search: https://docs.rwu.edu/saahp_fp/34
- Web search: https://onlinelibrary.wiley.com/doi/10.1111/j.1468-5922.2011.01952.x
- Web search: https://philpapers.org/rec/KARFAJ
- Web search: https://cms.academyofathens.gr/sites/default/files/2025-03/Fazzo%20S.%20-%20Aristotle,%20the%20Single%20Intellect,%20and%20Artificial%20Intelligence.pdf
- AI tutor: ollama deepseek-v4-pro
- Web search: https://www.athensjournals.gr/philosophy/2025-6986-AJPHIL-Ramozzi-Chiarottino-02.pdf
- Web search: https://ojs.zrc-sazu.si/filozofski-vestnik/issue/view/442
- Web search: https://brinkley.blog/2022/10/31/imagination-aristotle-kant/
- Web search: https://doi.org/10.21555/top.v29i1.214

## 13세기 파리 대학에서 아베로에스(Averroes)를 통해 이 해석이 확산되자, 토마스 아퀴나스(Thomas Aquinas) 등은 개별 영혼의 불멸을 옹호하며 단일지성론을 반박했다.

Type: highlight
Source: Aristotelianism, before Materialistic Atomism


## 에피쿠로스학파는 원자론을 받아들여 죽음 이후 원자의 해체로 인한 소멸을 강조하며, 죽음에 대한 공포를 제거하는 데 초점을 맞췄다

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 프네우마(pneuma)

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## apatheia

Type: question
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self

- AI tutor: ollama deepseek-v4-pro

## 죽음을 영혼을 구성하는 원자 복합체의 물리적 해체로 받아들이면 쾌락이나 고통을 경험할 주체가 사라지므로 두려움이 사라집니다.

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 인과의 사슬이 개인의 내적 판단과 동의를 통과하기 때문에, 우리는 그 행동의 진정한 원인으로서 책임을 질 수 있습니다

Type: question
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self

- Web search: https://www.jstage.jst.go.jp/article/rsjars/99/1/99_1/_article/-char/en
- Web search: https://poetcommons.whittier.edu/cgi/viewcontent.cgi?article=1009&context=phil
- Web search: https://www.mdpi.com/2077-1444/16/7/874
- Web search: https://poetcommons.whittier.edu/cgi/viewcontent.cgi?article=1010&context=phil
- Web search: https://doi.org/10.3390/rel16070874
- AI tutor: ollama deepseek-v4-pro
- Web search: https://www.academia.edu/36700572/Augustine_On_Free_Will
- Web search: https://www.cambridge.org/core/books/augustine-on-the-free-choice-of-the-will-on-grace-and-free-choice-and-other-writings/078B0C65D23789318CD663A7A36C4DC1
- Web search: https://lionandlambapologetics.org/wp-content/uploads/2021/11/Augustinian-Compatibilism-and-the-Doctrine-Cary.pdf
- Web search: https://philarchive.org/archive/DAVFWA
- Web search: https://www.academia.edu/166169081/THE_HARMONY_OF_GRACE_AND_FREE_WILL_AUGUSTINUS_TOME_III_BOOK_VIII

## 인간의 마음에는 '인상(phantasiai)'이 주어지고, 이에 대해 동의(synkatathesis)하거나 거부할 수 있는 능력이 있다.

Type: question
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self

- Web search: https://info-brainx.com/%ec%9e%90%ea%b7%b9%ea%b3%bc-%eb%b0%98%ec%9d%91-%ec%82%ac%ec%9d%b4-%ea%b3%b5%ea%b0%84-%eb%aa%85%ec%83%81/
- Web search: https://youwin.tistory.com/365
- Web search: https://www.dbpia.co.kr/journal/articleDetail?nodeId=NODE10740174
- Web search: https://www.accesson.kr/kcpa/assets/pdf/20587/journal-22-1-1.pdf
- Web search: https://magazine.brique.co/article/vol-14-mindfulness-seoyoun/
- AI tutor: ollama deepseek-v4-pro

## 소유권 개념의 확장: 외부 재산뿐 아니라 개인이 자신과 맺는 관계에도 소유권을 적용

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 자연적 노예제 거부

Type: question
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self

- Web search: https://sourcebooks.web.fordham.edu/ancient/stoic-slavery.asp
- Web search: https://www.loebclassics.com/view/marcus_aurelius-sayings/1916/pb_LCL058.363.xml
- Web search: https://donaldrobertson.name/2017/11/05/did-stoicism-condemn-slavery/
- Web search: http://penelope.uchicago.edu/Thayer/E/Roman/Texts/Dio_Chrysostom/Discourses/14*.html
- Web search: https://en.wikisource.org/wiki/Moral_letters_to_Lucilius/Letter_47
- AI tutor: ollama deepseek-v4-pro

## 이들은 유아기부터 생명체가 자신을 보존하려는 본능적 충동을 가지며, 이것이 점차 의식적인 자기 인식으로 발달한다고 보았습니다. 이 자기 인식은 단순한 인지가 아니라 자신을 돌보고 가치 있게 여기는 정서적 관계로, 이것이 바로 자기 소유와 책임의 토대입니다.

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 오이케이오시스

Type: lookup
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self

오이케이오시스는 스토아 윤리학의 핵심 개념으로, 인간을 포함한 모든 생명체가 자신에게 속한 것(자기 자신)을 인지하고 그것을 보존하려는 근본적인 충동을 의미합니다. 이는 단순한 자기애를 넘어, 이성이 발달함에 따라 자신의 가족, 공동체, 나아가 전 인류를 '자기 것'으로 인식하는 도덕적 성장의 기반이 됩니다.

이 이론은 스토아 철학의 창시자 제논의 사상에서 비롯되었으며, 개인이 자신의 본성에 따라 살면서 어떻게 이기적인 충동에서 벗어나 보편적 이타주의로 나아갈 수 있는지를 설명하는 중요한 장치입니다. 예를 들어, 부모가 자식을 자신의 일부처럼 돌보는 자연스러운 행위에서 오이케이오시스의 확장된 모습을 볼 수 있습니다.

- Wikipedia (en): https://en.wikipedia.org/wiki/Oikei%C3%B4sis
- AI Korean summarizer: ollama deepseek-v4-pro

## 스토아학파는 책임이 '개인이 자신과 맺는 심리적 관계'에 기초한다고 보았습니다

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 크리시포스(Chrysippus)는 '의식(consciousness)'이라는 단어를 사상 최초로 사용하며, 모든 동물이 자신의 고유한 구성뿐 아니라 그 구성에 대한 의식까지도 전유(appropriation, oikeiosis)한다고 주장했습니다.

Type: question
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self

- AI tutor: ollama deepseek-v4-pro

## Chrysippus

Type: lookup
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self

크리시포스(Chrysippus)는 스토아 학파의 체계를 완성하고 논리학의 기초를 다져 '제2의 창시자'로 불린 핵심 인물입니다. 그는 스토아 학파의 창시자 제논(Zeno of Citium)의 가르침을 확장하고 방대한 저술을 통해 학파의 교리를 정교화하여, 이후 스토아 철학이 고대 세계에서 지배적인 사상으로 자리 잡는 데 결정적인 역할을 했습니다.

특히 크리시포스는 명제 논리 체계를 발전시켜 아리스토텔레스의 삼단논법을 뛰어넘는 논리학의 기반을 마련했으며, 이는 현대 논리학의 선구적인 업적으로 평가받습니다. 또한 그는 모든 사건이 엄격한 인과율에 의해 결정된다는 운명론을 주장하면서도, 인간의 내적 동의라는 개념을 통해 도덕적 책임의 여지를 확보하려 했습니다.

- Wikipedia (en): https://en.wikipedia.org/wiki/Chrysippus
- AI Korean summarizer: ollama deepseek-v4-pro

## 자기 지시적이고 통합된 의식 개념

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 물질적 변화가 인격을 바꾸지는 않으며, 각 개인은 평생 변하지 않는 고유한 본질(essence)을 지닌다는 스토아적 견해를 가졌습니다.

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 이런 생각은 로마 시대에 신플라톤주의(Neoplatonism)와 아우구스티누스(Augustine)의 영향으로 가려져, 근대적 관계적 인격 동일성으로 이어지지 못했습니다.

Type: question
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self

- Web search: https://doi.org/10.1177/106385120201100115
- Web search: https://diametros.uj.edu.pl/diametros/en/article/download/409/433/841
- Web search: https://journals.sagepub.com/doi/10.1177/0959354302126002
- Web search: https://onlinelibrary.wiley.com/doi/10.1111/heyj.12166
- Web search: https://www.cambridge.org/core/journals/new-blackfriars/article/abs/whose-self-which-unification-augustines-anthropology-and-the-psychologytheology-debate/E26106EF30121500C9321458923107DC
- AI tutor: ollama deepseek-v4-pro

## 이 패러다임 안에서 자아의 문제는 '어떻게 물질적 변화 속에서도 동일한 인격으로 남는가'가 아니라 '어떻게 죄 많은 육체를 벗고 신에게 나아가는 영혼이 될 것인가'로 재편되었습니다. 그 결과 크리시포스의 통찰은 근대까지 주목받지 못하게 됩니다.

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 인격 동일성의 기준은 동일한 실체(영혼이나 신체)가 아니라 동일한 의식이다. 의식이 현재의 자아를 과거의 행위와 연결할 수 있다면, 그 행위는 바로 그 인격의 것이다.

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 기억은 의식의 연속성을 확장하는 핵심 도구이다

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 즉 신체적 연속성과 타인의 기억 속에 남은 서사

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 신플라톤주의는 영혼을 불변하는 실체로 보았기에, 정체성을 심리적 연결이나 사회적 관계로 설명하려는 시도가 설 자리를 잃었습니다.

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 자아는 사회적 상호작용과 내적 서사를 통해 지속적으로 구성되고 재구성된다.

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 신체 변화뿐 아니라 기억 상실이나 성격의 급격한 단절도 인격 동일성에 영향을 미칠 수 있다.

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 신플라톤주의와 아우구스티누스의 실체적 영혼론에 흡수되어 관계적 발전이 차단되었다.

Type: question
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self

- AI tutor: ollama deepseek-v4-pro

## 자아의 정체성을 뇌의 기능으로 환원하는 초기 형태입니다. 이러한 관점은 원자론자들이 제시한 물질적 세계관을 인간의 내면에 적용한 것으로, 이후 의학적 유물론의 토대가 됩니다.

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 모든 질병은 인간의 물리적 구성(physis)에 기초하며, 정신 질환도 예외가 아니다.

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 의학적 유물론은 정신 질환을 신체 질환처럼 다루므로, 환자를 도덕적 비난에서 해방시키는 효과가 있습니다. 그러나 동시에 자아의 자율성을 뇌 상태로 환원해 버리면, 스토아가 강조한 이성적 자기 통제의 여지가 줄어들 수 있습니다. 이 긴장은 오늘날 신경과학과 형사 책임 논의에서도 반복됩니다.

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 그래서 마음 자체를 '프네우마(pneuma)'라는 얇고 빠르게 움직이는 일종의 영적 물질로 보고, 뇌를 중심으로 신경을 통해 온몸에 뻗어나가는 덩굴손처럼 작용한다고 생각했습니다.

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## Herophilus

Type: lookup
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self

헤로필로스(Herophilos, 라틴어식 이름은 Herophilus)는 인체 해부학의 아버지로 불리는 고대 그리스 의사로, 최초로 인체 해부를 체계적으로 수행하여 과학적 해부학의 기초를 세운 인물입니다. 그의 업적은 단순한 시체 절개를 넘어 인체 구조에 대한 실증적 지식을 축적했다는 점에서 의학사적으로 매우 중요합니다.

그는 알렉산드리아에서 활동하며 뇌와 신경계, 혈관계 등에 대한 선구적인 관찰을 남겼고, 당시에는 드물게 인체 해부를 직접 시행했지만, 그의 방대한 저작들은 모두 소실되어 후대 기록을 통해 그 내용이 전해지고 있습니다.

- Wikipedia (en): https://en.wikipedia.org/wiki/Herophilos
- AI Korean summarizer: ollama deepseek-v4-pro

## Erasistratus

Type: lookup
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self

에라시스트라토스(Erasistratus)는 고대 그리스의 해부학자로, 신경계의 기능을 최초로 체계적으로 연구하여 신경과학(neuroscience)의 선구자로 평가받습니다. 그는 뇌가 운동 조절의 중심이며 신경을 통해 골격근에 명령을 전달한다는 사실을 밝혀내, 당시 지배적이었던 체액 병리설(humoral theory)과는 근본적으로 다른 기계론적 생리학의 기초를 놓았습니다.

그는 알렉산드리아에서 헤로필로스(Herophilus)와 함께 해부학 학파를 세우고 인체 해부를 직접 수행했으며, 이 과정에서 감각 신경과 운동 신경을 구분하고 심장 판막의 기능을 설명하는 등 놀라운 발견을 이뤘습니다. 특히 그는 모든 질병의 원인을 체액의 불균형에서 찾던 히포크라테스 전통의 의학 이론에 반대하고, 대신 장기와 조직의 구조적 이상이 병을 일으킨다는 고형 병리학(solidism)의 초기 개념을 주장했습니다.

- Wikipedia (en): https://en.wikipedia.org/wiki/Erasistratus
- AI Korean summarizer: ollama deepseek-v4-pro

## 자아가 자신의 신체를 '자기 것'으로 느끼고 통제할 수 있는 물리적 기반을 제공합니다. 이는 앞서 본 오이케이오시스(oikeiosis)의 생리학적 메커니즘

Type: highlight
Source: Materialistic Atomism, before [ 28 ] the rise and fall of soul and self


## 후기 고대에 플라톤의 영혼-육체 이원론이 종교적 사상가는 물론 의사들 사이에서도 우세해지며 자연주의적 접근이 쇠퇴했다.

Type: highlight
Source: [ 28 ] the rise and fall of soul and self, [ 28 ] the rise and fall of soul and self


## 17세기 물질적 세계관과 만나 근대 과학과 데카르트의 새로운 심신 이원론을 동시에 추동했다.

Type: question
Source: [ 28 ] the rise and fall of soul and self, [ 28 ] the rise and fall of soul and self

- AI tutor: ollama deepseek-v4-pro

## 같은 회의주의가 한쪽에서는 마음을 물질적 세계의 일부로 밀어 넣는 과학을, 다른 쪽에서는 마음을 물질로부터 분리하는 이원론을 낳았다는 이 역설

Type: question
Source: [ 28 ] the rise and fall of soul and self, [ 28 ] the rise and fall of soul and self

- AI tutor: ollama deepseek-v4-pro
