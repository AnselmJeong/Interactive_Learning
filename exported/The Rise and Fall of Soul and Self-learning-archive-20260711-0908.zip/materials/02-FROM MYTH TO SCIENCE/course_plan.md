# FROM MYTH TO SCIENCE
Source-grounded adaptive learning material

Estimated time: 30 minutes

## Modules

1. **From Myth to Science**
   원문을 직접 읽지 않아도 FROM MYTH TO SCIENCE의 핵심 주장과 긴장을 설명할 수 있다.
2. **The Rise and Fall of Soul and Self**
   원문을 직접 읽지 않아도 [ 12 ] the rise and fall of soul and self의 핵심 주장과 긴장을 설명할 수 있다.
3. **Platonism**
   원문을 직접 읽지 않아도 Platonism의 핵심 주장과 긴장을 설명할 수 있다.
4. **Aristotelianism**
   원문을 직접 읽지 않아도 Aristotelianism의 핵심 주장과 긴장을 설명할 수 있다.
5. **Materialistic Atomism**
   원문을 직접 읽지 않아도 Materialistic Atomism의 핵심 주장과 긴장을 설명할 수 있다.
6. **The Rise and Fall of Soul and Self**
   원문을 직접 읽지 않아도 [ 28 ] the rise and fall of soul and self의 핵심 주장과 긴장을 설명할 수 있다.
