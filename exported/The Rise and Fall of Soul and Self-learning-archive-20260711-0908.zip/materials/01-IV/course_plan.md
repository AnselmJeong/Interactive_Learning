# IV
Source-grounded adaptive learning material

Estimated time: 30 minutes

## Modules

1. **Resurrected Self**
   원문을 직접 읽지 않아도 RESURRECTED SELF의 핵심 주장과 긴장을 설명할 수 있다.
2. **The Resurrection**
   원문을 직접 읽지 않아도 The Resurrection의 핵심 주장과 긴장을 설명할 수 있다.
3. **The Triumph of Dualism**
   원문을 직접 읽지 않아도 The Triumph of Dualism의 핵심 주장과 긴장을 설명할 수 있다.
4. **The Augustinian Synthesis**
   원문을 직접 읽지 않아도 The Augustinian Synthesis의 핵심 주장과 긴장을 설명할 수 있다.
5. **Resurrected Self**
   원문을 직접 읽지 않아도 resurrected self [ 71 ]의 핵심 주장과 긴장을 설명할 수 있다.
6. **The Rise and Fall of Soul and Self**
   원문을 직접 읽지 않아도 [ 74 ] the rise and fall of soul and self의 핵심 주장과 긴장을 설명할 수 있다.
