# Translating the Odyssey

Mistakes are possible in translation, as every language instructor knows. But there is never a single ‘correct’ translation of a specific word, phrase, sentence or passage. There are a wide variety of responsible ways to create an equivalent, just as there are many ways to play a single score of music, many ways to paint the same landscape, and many ways to direct a play or deliver a speech.

This point applies to translation in general, not only literary translation, and not only translation from ancient languages. The text on a shampoo bottle or a menu or a street sign can, like an ancient epic poem, be translated several different ways. Idiomatic metaphors, syntax and socio-linguistic connotations are rarely the same across languages. But this general fact can be hard to absorb in the abstract, especially for people who are not themselves practising translators. A simple way to glimpse the range of possible approaches to translation, and to get a first taste of how approaches to translation have changed over time, is to look at several different retranslations of the same passage.

This essay is inspired by a set of threads I wrote on what was then Twitter, in the wake of the publication of my translation of the *Odyssey* in 2017, in which I used close reading to invite readers to a more precise awareness of what’s at stake in the variety of Homeric translations into English. I have heard from many teachers who have used these threads in their classroom and found it useful to generate student discussion. So I provide here a new version of this exercise, to provide a more explicit account of this book’s central ideas about the pleasures and perils of translation. A close examination of the numerous English translations of Homer reminds us how very difficult it is to recreate something like the meanings, effects, sounds and rhythms of ancient poetry in English – a language that did not exist in ancient times. And yet the enormous variation between Homeric translations also shows the vast range of ways we can reimagine antiquity, and illuminate the surprising gaps and connections between the ancient world and our own.

I have prioritised the translations that are most commonly read and cited in the contemporary anglophone world, and those that most clearly represent distinct approaches to the retranslation of the *Odyssey*. These priorities are slightly in tension with one another: several of these translations are quite similar in approach – unsurprisingly, since humans are mimetic animals. It is also worth looking at a couple of important pre-twentieth-century translations, to appreciate how shifts in our own culture have shaped approaches to translation more broadly. The earliest are the marvellous translations into rhyming fourteeners (for the *Iliad*) and rhyming pentameter couplets (for the *Odyssey*) by the great Elizabethan/Jacobean poet of revenge tragedies, George Chapman. Chapman was the first person to publish complete translations of these epics into English (1616, with instalments appearing earlier). His *Seven Books of the Iliades* was a source for Shakespeare’s *Troilus and Cressida*. I also discuss the sublime rhyming couplet translation by the eighteenth-century poet Alexander Pope. By modern standards of translation, both Chapman and Pope often seem more like ‘imitations’ than translations – a fact that itself illustrates a historical shift in literary translation practices.

I also look at more recent examples, including the peculiar prose translation by the satirical Victorian novelist Samuel Butler (1900). This version is odd in interesting ways, and is still fairly widely read, perhaps largely because it is out of copyright and therefore available for free online – and maybe also because of the misperception that prose is easier to read than verse. Another, very different in approach and style, is the verse translation by Robert Fitzgerald (1961), which uses a largely iambic rhythm and is notable for its artful use of literary allusions and poeticisms. From the same era and also from the US, Richmond Lattimore’s 1965 translation uses long, unmetrical lines (no iambs or dactyls are audible here), and an unidiomatic, archaising style. Lattimore is often touted as the most ‘literal’ translator (although, as we’ve seen, the reputation for extraordinary fidelity is not fully deserved). Another important example of the ‘literal’ style is the prose translation published by the Loeb Classical Library in archaising prose by A. T. Murray, lightly revised by George Dimock in 1995. I also look at what was by some distance the bestselling American version for a good twenty years, Robert Fagles’ lively, often melodramatic version in unmetrical free verse (1995). Stanley Lombardo’s snappy, slangy translation in very chatty free verse (2000) reads sometimes like a stripped-down adaptation of Fagles; it is still quite popular with instructors hoping to coach reluctant readers through the *Odyssey* in a short time*.* I hope this sampling will provide at least a glimpse of the rich array of choices facing the translator.

My primary goal in looking closely at a few translations side by side is to show readers who cannot access the Greek the multifarious ways of responding responsibly to the same original. Not all of these translators’ choices are equally valid. I myself spend many hours of every day wrestling with alternative possibilities in my own translations in progress, in an eternal quest to find a better solution – a more truthful evocation of a poetic experience that might parallel that of the original. I go through innumerable drafts, and I am always aware that my ‘final’ drafts include numerous compromises: the goal, for me and for all of us, is not the perfect translation, but a translation that is, for now, better than anything else I could come up with.

But what counts as ‘better’ depends, as this exercise demonstrates, on the translator’s priorities. Recreating the traditional metre of the original is a priority for some, and not at all for others. Some try for an equivalent emotional effect; some strive for an equivalent register; some for similar word order or similar syntax. It is often impossible to achieve all these things in the same translation. One of these approaches is not ‘right’ while the others are ‘wrong’: rather, each reflects a different way to present the original poetic style in a new linguistic and literary context.

When you look at these translations alongside each other, it soon becomes clear that translators have tried numerous different styles of language to make their English match the Greek. For poets in the eras of Chapman or Pope, it would have been unthinkable to translate Homer into prose (let alone free verse, which of course did not yet exist). But for many in the twentieth and twenty-first centuries, variations on more or less grandiloquent prose, or prose laid out as verse, have been viewed not only as the most authentic, but also as the most ‘poetic’ ways of approaching the translation of the Homeric poems. The English language has changed since the time of Pope or even Butler, but, more importantly, readers’ perceptions of what counts as ‘poetic’ have changed. Readers with no ear for metre are far more common than they once were. Moreover, the general perception of Homeric poems is quite different in the twenty-first century. *The Odyssey* is now ultra-canonical, and often viewed as a wellspring of ‘Western civilisation’, whatever that may be, whereas in the time of Pope, when the *Aeneid* was far more central to the canon.

All translators know that any word, phrase, sentence or passage in one language can be rendered into another language in a thousand forms. The choices are not infinite, but they are always multiple. The ancient Greek word *anēr* cannot mean ‘woman’, ‘bunny rabbit’, or ‘buttered toast’. But it can mean either ‘man’ or ‘husband’ – and the choice might matter. Also, the connotations of both ‘man’ and ‘husband’ in English are not the same as those of the ancient Greek word, because our assumptions about gender and marriage are not the same – an insuperable but ever-present problem, created by the intertwining of language with its social contexts. The choices are all the more difficult because language is not simply a list of nouns: syntax and word order vary across languages. Ancient Greek, like other highly inflected languages, can vary word order much more than English can, so it is very difficult for a translator to recreate the word order or syntax of the original without creating a text that is significantly less idiomatic and less fluent. A translator of poetry may also want to take account of sound, rhythm, metre, alliteration, assonance, voice, perspective, mood, register, emotional effect, pacing, imagery, idiom, and a dozen other essential qualities of the original – or they may choose to ignore these things, in favour of other kinds of truth. How can we replicate all of the original text’s qualities and effects, using none of the same words? There is no obvious solution. And yet we try.

My first example is the first two lines of Book 5 of the *Odyssey*.

> Ἠὼς δ᾽ ἐκ λεχέων παρ᾽ ἀγαυοῦ Τιθωνοῖο ὤρνυθ᾽,
>
> ἵν᾽ ἀθανάτοισι φόως φέροι ἠδὲ βροτοῖσιν.

The lines are an interesting variation on the more usual ‘rosy-fingered Dawn’ (*rhododaktulos Ēōs*). At the start of Book 5, we meet Odysseus trapped on the island of the goddess Calypso, whose name suggests ‘hiding’. He spends his days weeping by the shore, longing for home, and his nights with the goddess, with whom he has spent seven years. The text leads us to believe that Odysseus’s feelings have changed, and that he may at some earlier time have enjoyed his time with this mysterious goddess: he longs for a homecoming now, ‘because the goddess no longer brought him joy’ (ἐπεὶ οὐκέτι ἥνδανε νύμφη). And yet he cannot escape: this deity detains him on her island ‘by necessity’. In response to Odysseus’s suffering, his eternally asexual patron goddess, Athena, has persuaded her father, Zeus, that they must send the messenger god, Hermes, to tell Calypso that she has to let her mortal consort go home to his mortal wife – back to the sphere in which he can achieve glory and an eternal name, which would be impossible if he were to accept Calypso’s offer to make him immortal and ageless, as her eternal lover.

The opening lines of the book remind us that Calypso is not the only goddess to have taken up with a mortal man. Dawn abducted Tithonus, a Trojan prince, and asked Zeus to make him immortal – but she failed to ask that he also be ageless, so he became shrivelled and weak, despite being unable to die. In later versions of the myth, he was transformed into a cicada. The parallel between Dawn and Calypso reminds us of the dangers that face a mortal man bedded by a goddess; for all her promises, divine Calypso threatens Odysseus’s power and autonomy, unless he can escape from her. Unlike Calypso, Dawn has managed to keep her lover in her bed forever – whereas Calypso will soon be pressured by Hermes into letting her man go.

With Homer’s usual restraint, none of the implications of the parallel are directly spelled out. But they are hinted at. In the second line, Dawn brings light to two very different groups of beings: the ‘deathless’ and ‘mortals’, who are denoted by words that are not etymologically or sonically related: *athanatoisi ... brotoisin*. The groups are together in that they share the same bright early light; but they are separated in the line, just as Dawn separates herself from Tithonus, and Odysseus will soon separate himself from Calypso. A final important parallel between these two lines and what follows is that Dawn is, like Hermes, a messenger who travels a long distance to bring light and enlightenment to two different kinds of being – one immortal, and one not. None of this is easy for a translator to reproduce with the same verve as the original.

Here are those two lines in the first complete published English translation, in fine rhyming couplets by George Chapman:

> AURORA rose from high-born Tithon’s bed,
>
> That men and Gods might be illustrated.

‘Illustrate’ was, in Chapman’s time, used in the same sense as to ‘illuminate’ the mind. There is apparently no instance (according to the *Oxford English Dictionary*) of ‘illustrate’ meaning only ‘to shed light on’ before 1625, so when Chapman was writing these lines, the primary connotation is that Dawn is bringing not merely physical, literal light, but enlightenment. Chapman was a Christian Neo-Stoic, and his interest in reading the *Odyssey* as a story of spiritual and educational progress is legible even in these ostensibly quite simple lines.

Now here is the eighteenth-century version by an equally brilliant poet, Alexander Pope, who had his own, very different, concept of Enlightenment. His translation is also in rhyming couplets.

> The saffron morn, with early blushes spread,
>
> Now rose refulgent from Tithonus’ bed

As is typical for his translation style, Pope adds several details that are not in the Greek, including the colour of ‘morn’ (she is not saffron or any other colour in the Greek), and the cute detail of the ‘blushes’. This version of ‘morn’ seems to be doing the walk of shame – embarrassed to be getting up from her adulterous bed. The morals and norms of Pope’s own time are clearly discernible in his translation. No archaic Greek goddess would feel the need to blush about being sexually active. It is also notable that both Pope and Chapman claim that the bed belongs to Tithonus. This is not suggested in the Greek, and would surely have been a surprising idea for an archaic Greek audience, given that the immortal goddess has chosen to share her abode, and her bed, with a kidnapped, powerless mortal. He could surely not be expected to bring his own furniture. But the mores of seventeenth- and eighteenth-century England have crept into the translations of this archaic Greek poem, such that the bed must belong to the male partner – no matter what nonsense it makes of the narrative.

In the early nineteenth century, the hymnodist, abolitionist and celebrated nature poet, William Cowper, created another version in unrhyming blank verse (1791).

> Aurora from beside her glorious mate
>
> Tithonus now arose, light to dispense
>
> Through earth and heav’n …

Cowper is noticeably loose, one could say inaccurate, in his domesticising rendition of the ‘deathless gods … mortals’: ‘earth and heav’n’ is not the same as ‘those who die and those who live forever’. The translation depersonalises, and imports language more familiar from Cowper’s hymns to his *Odyssey*. The marked prissiness of ‘dispense’ is an interesting choice, given that the Greek verb *pheroi* is an extremely common word for ‘bring’. Using dispense gives an almost medicinal tone to the scene. Cowper suffered from bouts of extreme depression and suicidality. He was dependent on opium, and relied on the numerous ‘opium dispensaries’ (the term in current usage at his time of writing) that provided relief for those in need of the sedating poppy. Cowper may or may not have been consciously making the connection, but his rendition of this scene seems to hint that Aurora resembles those kind pharmacists: she is dispensing the good stuff both on earth and in heaven.

Here’s Samuel Butler’s prose translation from the turn of the twentieth century.

> And now, as Dawn rose from her couch beside Tithonus
>
> – harbinger of light alike to mortals and immortals …

The use of ‘harbinger’ strikes me as misleading: the Greek says that Dawn actually brings the light, not that she is the announcer of light that is being conveyed by some other means. I would also note that the addition of ‘alike’ and the very neat parallelism of ‘mortals and immortals’, with the ‘mortals’ put first, creates an effect quite different from the Greek, which uses words from two different linguistic roots, and separates them: Butler suggests that mortals and immortals are very much the same, at least in how they experience light – whereas an essential point in the first half of Book 5 is that mortals and immortals are not, and should not be, as close as all that. Butler also skips Tithonus’s honorific epithet.

From the twentieth century, the Loeb Classical Library prose version, by A. T Murray and revised by George Dimock, reads as follows:

> Now Dawn arose from her couch from beside lordly Tithonus, to bear light to the immortals and to mortal men.

The Loeb, with its parallel printing of the original next to the translation, is often imagined to be the most ‘literal’, in the sense of being measurably more accurate than prettier versions could be. But this is debatable in general: if the original is noticeably beautiful, elegant and poetic, the translation should arguably reflect those qualities. In this pair of lines, there are several questionable choices. For instance, the translation adds ‘her’ to the ‘couch’ and adds ‘men’ to the mortals: the Greek does not say to whom the bed belongs, and does not suggest that light falls only on males. Clunky repetition (‘from … from’) is noticeable in the translation, where the original has elegant variation of prepositions (*ek ... par*). The translation also introduces a great many archaisms, including ‘couch’ (for ‘bed’), ‘bear’, ‘arose’, and ‘lordly’. None of the words in the Homeric Greek are unusual in the context of the poem, and most of them were still in usage in later, classical (or Attic) Greek – so it seems unlikely that their effect was quite as fancy or distanced as the lexicon chosen here. One might also debate the choice to render metrical poetry in prose.

I’ve heard people express affection for the admirably peculiar prose translation by T. E. Lawrence (1932), so here it is:

> Dawn rose from her marriage-bed beside high-born
>
> Tithonus to bring her daylight to both gods and men.

Lawrence is the only translator of those I have looked at for this exercise who makes the coupled pair actually married – which the Greek certainly does not imply. Given the various rumours about Lawrence’s sexual proclivities, it seems possible that he here works particularly hard to assure us that everything is above board and bourgeois in the world of the *Odyssey*. Lawrence also generously insists that both the bed and the light itself belong to Dawn (which is not said or implied in the Greek). The translation ‘gods and men’ removes the specific focus on mortality/immortality, which is the point of the binary in the Greek.

Here is the version by Robert Fitzgerald, from 1961:

> Dawn came up from the couch of her reclining,
>
> leaving her lord Tithonus’ brilliant side
>
> with fresh light in her arms for gods and men.

Fitzgerald was a good poet, and he makes interesting use of rhythm in his translations; the second and third lines here are in regular iambic pentameter, while the first line has a more trochaic beat. Fitzgerald avoided regular metre deliberately, on the advice of Ezra Pound, and reflections of Pound’s poetic sensibility can also be heard in Fitzgerald’s use of allusive, often vaguely biblical, markedly ‘literary’ language. The original is, of course, all in regular traditional metre, and Fizgerald’s poeticisms do not always map onto anything particular in the Greek. For instance, like the Loeb translators, he makes poor old Dawn sleep on the couch. If it were 1750, a couch would be a very different thing. And yet the Greek word *lechos* would probably not have felt noticeably archaic to a listener of Homer in the fifth century BCE, given that this is the same word used for ‘bed’ by Sophocles, Euripides and Aristophanes.

The ‘brilliant side’ is a strange and interesting addition; a literal-minded reader might wonder if he is less brilliant when he flips over. Tithonus, doomed to eternal life without eternal youth, was turned into a cicada: Fitzgerald’s translation perhaps suggests that he is shiny like a cicada (although none of that is suggested by the Greek). ‘Reclining’ and ‘leaving’ are also noticeable additions, which make Dawn a more leisurely, idle figure than she may seem from the Greek. The translation also makes Tithonus important not for his status in general (as per the Greek), but for his status over her – ‘her’ lord. It is tempting to speculate that the personal experiences of thrice-married Fitzgerald might have influenced his representations of such relationships in the *Odyssey*. My favourite additions in this translation are the ‘arms’ and the ‘fresh’, creating a lovely image of Dawn holding light as if it were a bouquet of newly gathered flowers – which could not possibly be got from the Greek, but is in itself quite charming.

Here is the unmetrical verse version of Richmond Lattimore, published in 1963, soon after Fitzgerald’s:

> Now Dawn rose from her bed, where she lay by haughty Tithonus,
>
> carrying light to the immortal gods and to mortals …

Although they are from the same country and era, Lattimore and Fitzgerald are very different in their approach to Homeric translation, to poetics, and to the poem’s sexual mores. ‘Haughty’ is a strangely judgemental choice for a word, *agauos*, that is generally used to suggest ‘general commendation’, ‘usually applied to elite characters’, to quote Richard Cunliffe’s *A Lexicon of the Homeric Dialect –* a key resource for any translator of Homer. ‘Haughty’ is usually a negative term, unlike *agauos*; one might detect in the translation an implicit criticism of this man who has the chutzpah to carry on his illicit affair up there in the sky. Lattimore adds several details that are not strictly in the Greek: ‘her’ bed, ‘where she lay’, and ‘now’. His syntax is also quite different from the Greek: Homer’s Dawn gets up in order to bring light (a purpose clause, with a finite verb); Lattimore’s Dawn is blessed with a present participle (‘carrying’), such that she seems to be lumbered with the light even while she is still abed. In general, this translator has a great fondness for participles, and often uses them even when the Greek has finite verbs that create a far more energetic effect. All this is worth spelling out, because Lattimore is often represented and seen as a particularly faithful translator. In fact, we all interpret. We dance different ways along the tightrope, trying to balance all the different truths.

I pause here for a note on metre. People have frequently told me adamantly that Lattimore’s Homeric translations are in dactylic hexameter, the metre of the original. This is false. I am not casting aspersions on an honoured and late-lamented colleague; Lattimore knew quite well that his lines were not hexameter, and he also made no claim to be writing ‘poetry’, whatever that may be. Lattimore’s lines have a range of different types of feet, and there are frequently more or fewer than six main beats in the line. To take this little sample as a metrical test case: in the first line, we have spondee, dactyl, dactyl, trochee, dactyl, spondee; the next definitely has only five feet at most, and definitely has two iambs (dactyl, dactyl, iamb, iamb, pyrrhic, trochee – an oddly trailing effect). There is no sign of rhythm. This stacked prose has some dactyls sometimes, but many other rhythms too, as prose does. The model of using irregular, unmetrical but long, meandering, often idiomatic lines to translate the Homeric dactylic hexameter has proven extremely popular in the twenty-first century, with a great many other anglophone translators following more or less the Lattimore model: these include versions by Peter Green, Barry Powell, Antony Verity, Caroline Alexander (*Iliad* only) and Daniel Mendelsohn (*Odyssey* only).

Published to great acclaim in 1996, here is the free verse version by Robert Fagles:

> As Dawn rose up from bed by her lordly mate Tithonus,
>
> bringing light to immortal gods and mortal men …

The Greek has no word equivalent to ‘mate’, and its insertion makes a difference; it suggests an almost animalistic pairing that sits slightly strangely beside the grand, vaguely archaic ‘lordly’. The Greek does not label the relationship in any way; the listener is presumed to know how Dawn and Tithonus are connected. Like Lattimore and Fitzgerald, Fagles changes the purpose clause of the Greek to a participle (‘bringing’); as a result, in all of these translations, Dawn’s work of bringing light seems to happen without her conscious intent to carry it out. This is a significant change, because it reduces the connection between Dawn and Hermes, who are both travellers with a purpose. It is also interesting that Fagles, like several other translators, adds both ‘gods’ and ‘men’. You might think that everyone, including women and goddesses, might share the experience of Dawn’s light (and the Greek word *brotos* is used with a feminine article later in *Odyssey* book 5, line 334, to describe the White Goddess, Ino). Fagles eliminates the possibility that those blessed with light could be female. Perhaps he adds the nouns for sonic reasons: his rhythms are irregular but tending to iambic, and the addition of the nouns allows the line to resolve into a predominantly iambic sound.

Here is the free verse version by Stanley Lombardo (2000).

> Dawn reluctantly
>
> Left Tithonus in her rose-shadowed bed.
>
> Then shook the morning into flakes of fire.

I love ‘rose-shadowed’ and ‘flakes of fire’, although they are not in Homer at all. Lombardo stylishly stole them from Tennyson’s great poem, ‘Tithonus’, which has ‘rosy shadows’ and the marvellous line, ‘beat the twilight into flakes of fire’. These moves – like Lombardo’s playful quotation from Nabokov at the start of his *Odyssey* – raise interesting questions about what counts as a ‘translation’, as opposed to a fun reinvention inspired both by the original and various other somewhat related texts. It is also notable that Lombardo adds ‘reluctantly’ (corresponding to nothing in the Greek): in this version, poor Tithonus has no epithet and is only good for one thing. Lombardo makes Dawn a working lady, who finds it challenging to juggle her enjoyable sex life with her career responsibilities. The focus on mortality and immortality, and the various parallels between Dawn, Calypso and Hermes are eliminated in the translation.

This is my own version of these same lines:

> Then Dawn rose up from bed with Lord Tithonus,
>
> to bring the light to deathless gods and mortals.

As you can see from these examples, mine is the only modern one that has regular metre, using traditional iambic pentameter. I want to try to ‘translate’ the traditional poetic form of the original, in dactylic hexameter, by using its equivalent in English, the metre most associated with narrative verse in our literary heritage.

I spent many hours considering what to do with the purpose clause. I liked the almost-suggestion that Dawn is like a mail-woman, bringing the daily necessities to diverse populations – I wondered if some readers might hear, as I do, a buried echo of Larkin’s ‘Aubade’. But here as elsewhere, I wanted to avoid the clever literary allusions of Lombardo or Fitzgerald, since they are entirely out of place in Homeric poetics; the *Odyssey* is based on a pre-existing oral tradition, and cannot make smart little nods to earlier literature, because there was no earlier Greek literature.

The relative starkness of my version, compared to some of the more expansive translations, is deliberate. I tried, here and elsewhere, to avoid spelling out things that are resonantly unspoken in the original – such as to whom the bed belongs, and whether Dawn is glad or sorry to be getting up. The reader or listener has the right to dwell in ambiguities, when the original is meaningfully ambiguous, rather than having everything explained and glossed by the translator. One detail is to me an essential feature of the original Greek: that the ‘deathless’ and the ‘mortals’ are not linguistically or metaphysically alike. For that reason, I chose words from two different linguistic roots (‘deathless’ and ‘mortals’, rather than ‘immortal/mortal’), in contrast to many other translators, who bring the two categories closer together. I regretted not managing to do more alliteration, to reflect that of the original (*phoōs pheroi*), beyond the repeated ‘to’. I alliterate elsewhere, not always in the same places as the original, because it’s not always possible without adding elements that are pure invention (as Lombardo and Pope do).

How can a translator bring the light from ancient Greece to modernity? What does she bring with her, and what does she leave behind? For whom is the light shed? I hope this little exercise helps illustrate some of the many dilemmas, and the eternal, deathless, immortal fact that there is no one true right answer.

Implicit in many of these translation choices are various assumptions that translators bring from their own time period, including ideas about proper gender roles and sexuality, beliefs about labour and enlightenment, and changing literary norms about what makes a text sound ‘poetic’. The Homeric poems, like all ancient poetry, do not rhyme; and yet, in Chapman or Pope’s times, rhyme was a normal element in contemporary poetry, and is therefore introduced. Similarly, unmetrical free verse did not exist in antiquity, but twentieth-century translators often use it because it is a normal poetic form to contemporary readers. Grand vocabulary words and archaisms are viewed as ‘poetic’ by many twentieth- and twenty-first-century readers, and so they make their way into translations of ancient poetry – regardless of the lexical register of the original.

Modern popular reception of ancient poems can also shape modern translations, even when there is a clear gap between the ancient text and later reinventions of the story. One example is the story of the Sirens from the *Odyssey*, the divine female singers who tempt all those who sail past to listen to them forever, forgetful of their families. Odysseus, instructed by Circe, has himself bound to the mast so he can listen to their song. He also has his men bung up their ears with wax so they cannot hear and be tempted. In the modern popular imagination, the Sirens are tempting because they are sexy mermaid-like ladies, as in the Siren scene in the Coen brothers film, *O Brother Where Art Thou*. From a modern perspective, the Homeric Sirens passage is surprising in at least two ways. One is how short it is; the episode has become a much bigger part of the *Odyssey* in modern retellings than it is in the Homeric original. Secondly, the Sirens in Homer are not sexy. The modern visual iconography of Sirens as scantily clad mermaids is very different from ancient depictions (vases, mosaics etc.), which make them bird-women-poets; they often have musical instruments, the lyre and/or the aulos (double pipe), and offer a musical, aesthetic temptation, and a cognitive one: they promise to enable knowledge. In the Homeric text, we learn nothing even about their hair or ankles, in contrast to other divine temptresses in archaic Greek poetry. This fits with the visual iconographic tradition, in which Sirens often have bird legs and claws: the avian tarsometatarsus is not usually desirable to a human gaze. The seduction Sirens offer is based on their claim to know everything about the war in Troy, and everything on earth. They tell the names of pain. But there is a tendency among translators to fight back against these facts about the original text – perhaps not always consciously.

Here are three lines from the passage, in which the Sirens tell Odysseus he should stop and listen to them, as so many have done before:

> οὐ γάρ πώ τις τῇδε παρήλασε νηὶ μελαίνῃ,
>
> πρίν γ᾽ ἡμέων μελίγηρυν ἀπὸ στομάτων ὄπ᾽ ἀκοῦσαι,
>
> ἀλλ᾽ ὅ γε τερψάμενος νεῖται καὶ πλείονα εἰδώς.

The Loeb prose translation reads, ‘For never yet has any man rowed past the island in his black ship until he has heard the sweet voice from our lips; instead, he has joy of it, and goes his way a wiser man.’ The Greek word *stoma* means ‘mouth’; and yet this translation renders it as ‘lips’. It is, of course, possible to argue that English speakers are more likely to think of speech as emerging from the lips rather than the mouth. But the translation of mouth as ‘lips’ also fits in nicely with the modern perception of the Sirens as seductive, rather than cognitively tempting – especially when *tis*, the unnamed ‘someone’ who passes by in a black ship, is translated in emphatically gendered terms, as a ‘man’. ‘Man’ is repeated twice in the Loeb translation, and is not paralleled by a gendered noun in the Greek – although the traveller is implicitly male.

Modern anglophone translators seem to have been quite consistent in rendering the *stomatõn* of the Sirens as ‘lips’, and often add ‘man’ once or twice. Lattimore does the same thing: ‘the honey-sweet voice that issues from our lips’. Fagles, often an expansive translator, has ‘the honeyed voices pouring from our lips’. Lombardo also has lips, and turns the Sirens’ voice (*ops*) into the dehumanised ‘sound’, as if these goddesses were a strange and rather sticky kind of music machine: ‘listening to the honeyed sound from our lips’.

Of those I have looked at, the translator who does most to impose modern sexy mermaids onto the Homeric bird-like Sirens is Fitzgerald. He shifts to a different metre for their song, using italics and lovely ballad-like rhyming stanzas, and expanding so radically that three lines of Greek become thirteen in the translation:

> *Sweet coupled airs we sing.*
>
> *No lonely seafarer*
>
> *Holds clear of entering*
>
> *Our green mirror.*
>
> *Pleased by each purling note*
>
> *Like honey twining*
>
> *From her throat and my throat,*
>
> *Who lies a-pining?*
>
> *Sea rovers here take joy*
>
> *Voyaging onward,*
>
> *As from our song of Troy*
>
> *Greybeard and rower-boy*
>
> *Goeth more learnèd.*

Some details of the translator’s additions evoke Shakespeare, especially *The* *Tempest* (‘green mirror’, ‘coupled airs’); the passage would seem at home in Auden’s long poetic riff on *The Tempest*, ‘The Sea and the Mirror’. Some are more generically ballad-like or early modern (‘greybeard’, ‘a-pining’). Several of the additions make the Sirens seem much more seductive, in the traditional, ‘feminine wiles’ manner, than the original does: these Sirens have not mouths but ‘throats’, and their song seems designed to wind itself around the unsuspecting male traveller, ‘twining’ and ‘purling’.

In my own translation of this passage, I translate *stomatōn* literally as ‘mouths’.

> ‘Now stop your ship and listen to our voices.
>
> All those who pass this way hear honeyed song
>
> poured from our mouths. The music brings them joy,
>
> and they go on their way with greater knowledge.’

I wanted to match in my translation the impression that I see in the Greek: the Sirens are seductive, but in aural, musical and intellectual ways, not because they are sexy mermaids. I tried to echo some of the alliterating sibilants in the original, a bit like Kaa in *The Jungle Book*. I also felt that the literal rendition of ‘mouths’ was important, even if English idiom could accommodate ‘lips’, because it is the mouth, not the lips, that run through the poem’s central preoccupation with the themes of eating and being eaten. Mouths (of giants, goddesses, men, the sea itself) keep eating the wrong things, and mouths (of goddesses, men, witches, singers and shades) speak and sing to enable or thwart the onward journey. Unlike lips, which can be pretty and kissable, mouths are powerful and dangerous.

Perhaps the trope of kissable Sirens is a specifically modern interpretation. It is not legible in pre-twentieth-century translations. Chapman includes no lips, and focuses on cognitive ravishment rather than the other kind: his Sirens tell ‘Ulysses’ to ‘that song hear / That none past ever but it bent his ear, / But left him ravish’d, and instructed more / By us, than any ever heard before’. Similarly, Pope makes them offer quasi-spiritual enlightenment, and makes no mention of either lips or mouths: ‘Blest is the man ordain’d our voice to hear, / The song instructs the soul, and charms the ear’. The alluring mermaid became much more of a cultural touchstone during the nineteenth and twentieth centuries, with the rise in popularity of the ‘Little Mermaid’ and its various cinematic adaptations, and with the fusion of Scandinavian folk traditions of seductive sea-women with the ancient Siren myth. The phrases ‘siren song’ and ‘femme fatale’ have become much more common in English over the past eighty years. The common modern image of the sexy, seductive siren may seem ‘traditional’, and in a sense, it is – but traditions are often much more recent than we think.

The intertwining of modern values and prejudices with the translation of ancient texts affects many features of translation that have nothing to do with gender. One example is a passage of Book 9 of the *Odyssey*, in which Odysseus and his men encounter a huge, wild man – a Cyclops. In modern popular imagination, the Cyclops is a ‘monster’, who is often imagined as a dehumanised ‘savage’, a term associated with modern European and anglophone racialised stereotypes about other parts of the world. And yet in the Greek, Polyphemus is a human being, and the son of a god – although he is also strange to his Ithacan visitors in his habits and his physical appearance, and responds poorly to the appearance of uninvited guests, whom he swallows for dinner. He is terrifying, but he is not a different species from Odysseus – and in some ways, as the son of a god, he is superior rather than inferior to his visitors. Translators sometimes iron out this complexity by presenting Polyphemus as inhuman. We can see these tendencies in the translation of just a couple of lines. When Odysseus and his gang have blinded the Cyclops and snuck out of his cave, clinging to the bellies of the shepherd’s rams, they row away at top speed. But Odysseus can’t resist taunting his blinded victim. The men try to restrain him, with these words:

> σχέτλιε, τίπτ᾽ ἐθέλεις ἐρεθιζέμεν ἄγριον ἄνδρα;

Here, the men criticise Odysseus with a word suggesting ‘cruel’ or ‘unflinching’ or ‘stubborn’ – a word that Odysseus had earlier used to the Cyclops – and define the Cyclops explicitly as a human being, a man: *andra* is the same word used of Odysseus himself in line 1 of the poem. Polyphemus is defined as a country-dwelling or wild man (*agrion*). But he is definitely a person.

And yet several translations apply the word ‘man’ to Odysseus, but not to Polyphemus. The Loeb translation has, ‘Stubborn man, why will you provoke to anger a savage?’ Fitzgerald makes the men address Odysseus with an honourable title (not a term of criticism), and call Polyphemus not a man but a ‘beast’: ‘Godsake, Captain! / Why bait the beast again?’ Lombardo, as he does quite often, leaves most of this line out, and, like the Loeb, makes Odysseus the ‘man’, not the Cyclops. His rendition is simply, ‘Don’t do it, man!’ Fagles quotes Fitzgerald (as he frequently does), using ‘beast’: ‘So headstrong – why? Why rile the beast again?’

In my own translation, I wanted it to be clear, as it is in the Greek, that the Cyclops is defined as a human being. I render the line, ‘Calm down! Why are you being so insistent / on taunting this wild man?’ I used ‘wild’, which I felt captured something of how the Greek word hovers between neutral description (wild animals aren’t worse than tame ones) and judgement.

Translations are informed by, and inform, scholarly discourse as well as current popular receptions. The ‘savage’, ‘monster’ and ‘beast’ renditions are paralleled by the Oxford commentary by Albert Heubeck, which notes of the Cyclops people: ‘this race [*sic*], the embodiment of inhumanity, is endowed with non-human characteristics and is capable of acts of extreme barbarity.’ The notion of Polyphemus as ‘inhuman’ is both standard and highly debatable.

Grafting contemporary values onto ancient texts is, presumably, often done unconsciously. It is very rare for a translator to deliberately set out to distort the original she or he is translating. It can be as difficult for us to see the cultural assumptions of our own time as for a bird to see air, or fish water. For instance, in renditions of the violent scene in *Odyssey* book 22, in which Telemachus kills the thirteen enslaved people who have served the bodily desires of Penelope’s suitors, modern assumptions about sex and gender are often very clear in the translator’s choice of phrase.

After Odysseus has slaughtered the suitors who have been harassing his wife, he delegates the final set of killings to his son, Telemachus. These last victims are very different from those Odysseus himself kills: they are not armed young men, but unarmed enslaved people – the twelve women who have shared the suitors’ beds, and the one man who has brought them animals to eat. These thirteen people have been claimed by alternative owners, whom they remember, and they are therefore a threat to the ultimate goal of Odysseus’s homecoming, his *nostos*: to regain full control and honour in the house. The point is not that they must be punished because they have committed crimes or sins, out of their own lust or greed and through their own agency, but that, willingly or unwillingly, they have been used for the lust and greed of men other than Odysseus. Their continued existence therefore undermines his honour and that of Telemachus and Penelope. Odysseus instructs his son to hack the life out of them with long swords. Telemachus adjusts the weapon: he insists they are too metaphorically dirty to touch with his sword, so he hangs them instead. The rope round the throat provides the ideal way to stop a woman’s most threatening orifice, her mouth.

Before the killings, Telemachus insists that these enslaved people cannot have a ‘clean’ death, because they ‘poured’ shame on himself and his mother:

> μὴ μ ν δὴ καθαρῷ θανάτῳ ἀπὸ θυμὸν ἑλοίμην
>
> τάων, αἳ δὴ ἐμῇ κεφαλῇ κατ᾽ ὀνείδεα χεῦαν
>
> μητέρι θ᾽ ἡμετέρῃ παρά τε μνηστῆρσιν ἴαυον.

The women are described simply with a pronoun, *taōn* (‘of them’, feminine plural). There is no noun, and Telemachus does not level any term of abuse at them, beyond describing them as bringing shame. There is no way to tell whether Telemachus agrees with his father’s earlier claim, that the women were ‘forced’ into sex with the suitors (‘biaiōs’, ‘forcibly’, 22.38) – and, from the perspective of honour, it is irrelevant: they may have had little or no choice, but, nonetheless, they must die. Telemachus is ashamed and disgusted by the existence of women whose bodies have been claimed by other men. Moreover, the social world of the Homeric warrior entails a focus on honour that is, in the domestic sphere, dependent on complete control of the bodies within the household, including the wife and the enslaved members of the estate. A man whose wife and/or slaves have been claimed by others is thereby humiliated, whether or not they wanted to be so claimed.

And yet many translations have him use lively terms of abuse in this passage, as if Telemachus were not performing an honour killing, but was instead punishing sexual miscreants. In Fagles’ bestselling version, Telemachus addresses them as ‘You sluts – the suitors’ whores!’ Lombardo draws from Fagles: ‘sluts’. Lattimore uses ‘creatures’. Fitzgerald uses ‘sluts’. The version by Alexander Pope has the liveliest term of abuse: he calls them ‘nightly prostitutes to shame’ (a vivid image that corresponds to nothing in the Greek).

One might be tempted to think that the sexualised condemnation of these murdered women by male translators was an inevitable result of the translators’ gender. But this notion fails to fit the evidence. The Anne Dacier version in French prose was the first known complete published translation by a woman (1716), and Dacier suggests an active plot to sow disorder in the bourgeois home on the part of these messy, nasty girls:

> Il ne faut point faire finir par une mort honorable des créatures qui nous ont couverts d’opprobre ma mère et moi par la vie infame qu’elles ont menée, et par tous les désordres qu’elles ont commis.
>
> [One must not make the end of an honourable death for creatures who have covered my mother and myself with shame by the life of infamy they led, and by all the disturbances they created.]

The word ‘*créatures’* dehumanises the victims, and instead of the neutral description of behaviour (they ‘lay beside’ the suitors, *para te mnēstērsin iauon*), the women are said to have led a ‘life of infamy’, *la vie infame*, and created a lack of order in the household (*désordres*). Dacier was a pioneering translator, who fought hard against the ‘pretty little liars’ perception of poetic translation popular in her time (more artful translations were known as *les belle infidèles*). Against the elegant, metrical, rhyming versions of her peers, she reimagined Homeric poetry in sturdy French prose, presenting the ancient epic in a way that could shore up good Christian, French values, and address the servant problem at the same time. It is likely that Pope’s moralising against the ‘prostitutes of shame’ is motivated not so much by his gender identity as by his sources: his Greek was shaky, and he used Dacier extensively.

Why do so many translators and scholars, both male and female, choose to put terms of abuse into the mouth of Telemachus, and present the killing as motivated by righteous rage, not shame? One possible answer is that this interpretation fits better with modern social norms and assumptions. A modern writer might assume that Telemachus would lose all sympathy from the reader if the killings were not seen to be motivated by something very bad that the victims had done. Killing to defend one’s honour is not normally considered appropriate in modern societies. Perhaps, too, modern forms of misogyny tend to focus directly on women’s sexuality rather than on the dangers they may pose to the household and the honour of the male householder*.* A final reason, perhaps the most important, is entropy: once one translation has a sexualised term of abuse, others follow – regardless of whether it parallels or makes sense of the Greek.

This same passage provides an opportunity to examine how a translator might – by accident or design – cut complexities from a passage that might represent more than one point of view. Homeric scholarship over the past couple of decades has moved towards a much more nuanced and detailed recognition of how perspective shifts around in Homer, and how rarely we are limited to only one character’s feelings or experiences. On the battlefield, we see both the killers and the killed; and here too, in the killings within Odysseus’s house, we can hear both the perspective of the killer – the fragile young person eager to prove himself as a man, and to slough off the burden of many years of humiliation and of being bullied in his own home – and the perspective of those killed, who want to go home, to bed, and who do not want to die. And yet many English translations limit the perspective, so that the narrative seems to be focused largely or entirely on the eyes of the killer, not the victims.

A great Homeric simile describes the women’s death. They are like birds, trying to fly, who are trapped in a net. One can take this simile as a mark of the narrator’s broad sympathies, which include pity for those killed so that the protagonist can regain his full renown. One man gets his successful journey home from war, his *nostos.* This word, from which we get ‘nostalgia’ (the pain of never getting back to the past), suggests a physical journey. But the *Odyssey* reminds us that homecoming may be more than a geographical process. It also entails the rebuilding and destruction of relationships and of memories, both of which are essential to the construction of a household as a generator of honour for its master. For Odysseus to regain his glorious identity as lord of Ithaca and owner of his household and estate, others – like these birds, flying to their homes and ending up in a net, or these women, whose throats are silenced by the rope, whose feet are immobilised by the drop – will never go anywhere again. Their dream to achieve a *nostos* will never be fulfilled.

Alternatively, one could take it that the simile serves primarily to dehumanise the victims: perhaps they are compared to birds to reduce our sympathy, because nobody really cares about birds. In translation, just as in criticism or commentary or teaching, there are interpretative choices and forks in the path. Most of the translations I have looked at seem to take the second path, although to me, the first makes better sense of the Greek, and fits better with the breadth of Homeric vision – the ability of these epics to invite us to see more than one point of view, even or especially in scenes of violence and dominance.

Here is the simile in Greek:

> ὡς δ᾽ ὅτ᾽ ἂν ἢ κίχλαι τανυσίπτεροι ἠ πέλειαι
>
> ἕρκει ἐνιπλήξωσι, τό θ᾽ ἑστήκῃ ἐνὶ θάμνῳ,
>
> αὖλιν ἐσιέμεναι, στυγερὸς δ᾽ ὑπεδέξατο κοῖτος,
>
> ὣς αἵ γ᾽ ἑξείης κεφαλὰς ἔχον, ἀμφὶ δ πάσαις
>
> δειρῇσι βρόχοι ἦσαν, ὅπως οἴκτιστα θάνοιεν.
>
> ἤσπαιρον δ πόδεσσι μίνυνθά περ οὔ τι μάλα δήν.

In his rendition, Chapman makes it unambiguous that these are wicked women by adding the biblical image of the sinner as ‘stubborn-necked’: the rope is put around the women,

> Till euery one
>
> Her pliant halter, had enforc’t vpon
>
> Her stubborne necke.

The Greek has no ‘stubborn’, and Chapman omits the Homeric narrator’s final evocation of pity as the proper response to these violent deaths (*oiktista*).

The women’s feet twitch in their death throes. Pope skips the feet and their final movement, and adds a quasi-Christian set of souls, which are clearly going you-know-where:

> Soon fled the soul impure, and left behind
>
> The empty corse to waver with the wind.

These choices might seem to illustrate the religious and gendered norms of the earlier translators’ benighted times. But the tendency to dehumanise the victims, and to blame them for their own deaths, is also present in twentieth- and twenty-first-century versions, although none of the modern translations are as explicitly Christianising as Chapman or Pope. The Loeb version of the simile reads,

> as when long-winged thrushes or doves fall into a snare that is set in a thicket, as they seek to reach their roosting place, and hateful is the bed that gives them welcome, even so the women held their heads in a row, and round the necks of all nooses were laid.

‘Held their heads’ suggests that they are willingly submitting to this natural process; the very common, relatively unmarked verb *echon* could suggest either ‘hold’ or ‘have’, but the Loeb translators choose to make the victims collude with their death.

Robert Fitzgerald makes the women even more eager to die:

> like doves or larks in springes triggered in a thicket,
>
> where the birds think to rest – a cruel nesting.
>
> So now in turn each woman thrust her head
>
> into a noose and swung, yanked high in air,
>
> to perish there most piteously.
>
> Their feet danced for a little, but not long.

‘Thrust her head’ suggests that the women are longing, perhaps even lusting, for death. The suggestions of sexualised promiscuity are underlined by Fitzgerald’s characteristic use of artful literary allusion: ‘springes’ recalls Polonius warning Ophelia not to let Hamlet take her virginity, telling her that the seductive words of young men are ‘springes to catch woodcocks’. Implicitly, the translation presents these young women as a dozen fallen Ophelias, who have yielded to illicit sexual impulses – and have, like Ophelia, killed themselves. The final movement of their suspended feet (*ēspairon* – a word used almost exclusively for the last twitching movements or gasps of the dying) becomes, with a new metaphor invented by Fitzgerald, a dance; there is a clear connection between the bad kind of fun the women have enjoyed in life, and their suspended deaths.

Fagles borrows the word ‘yanked’ from Fitzgerald, although it corresponds to nothing in the Greek, and he recalls the earlier translators’ image of these victims as party girls:

> Then, as doves or thrushes beating their spread wings
>
> against some snare rigged up in thickets –
>
> flying in for a cozy nest but a grisly bed receives them –
>
> so the women’s heads were trapped in a line
>
> nooses yanking their necks up, one by one,
>
> so all might die a pitiful, ghastly death …
>
> They kicked up heels for a little – not for long.

Where Fitzgerald makes Homeric poetry sound densely literary, with the Shakespearean allusion and the slight archaisms (‘piteously’), Fagles makes it veer between chattiness and melodrama. The childish half-rhyme, ‘cozy … grisly’ points to the horrorific mismatch between the women’s desires and their deaths – but also encourages us not to take their experiences too seriously. Fagles presents these ‘sluts’ (his choice of words) as girls who have partied too hard. They are hung ‘in a line’, like chorus dancers or clubbers on a night out.

Lombardo takes a somewhat different approach to the dying movements. His norm is to offset all Homeric similes with italics, so the birds exist in a different typographic mode from the women:

> *Long-winged thrushes, or doves, making their way*
>
> *To their roosts, fall into a snare set in a thicket,*
>
> *And the bed that receives them is far from welcome.*
>
> So too these women, their heads hanging in a row,
>
> The cable looped around each of their necks.
>
> It was a most piteous death. Their feet fluttered
>
> For a little while, but not for long.

The translation suggests that even at the moment of their deaths, the women are still like birds, fluttering – they are dehumanised in their last moments. ‘Roosts’ makes the birds’ home definitely non-human, although the Greek term *aulis* is used to describe human encampments or tents. The archaism ‘piteous’ creates distance: from afar, we can observe that something painful is happening to someone else, but we don’t need to feel it ourselves.

In my own translation of this passage (current version, slightly revised from the first published version), I wanted to reflect what I see in the Greek, which is a simile that increases rather than decreases our sense of pity at the deaths of these women – who wanted only what Odysseus himself wants, to go home and go to bed.

> As doves or thrushes spread their wings to fly
>
> home to their nests, but someone sets a trap –
>
> they crash into a net, a bitter bedtime –
>
> just so the women, heads all in a row,
>
> were strung up with the noose around their necks
>
> to make their death most pitiful. They gasped,
>
> feet twitching for a while, but not for long.

The violence of the Greek passage, as I read it, is presented with understanding and compassion both for the killer and for those he kills. Their final movements are not joyful, and they do not want to die. The narrator explicitly invites our pity for them. The simile reminds us that the homecoming of Odysseus means that many others will never get to go back to their homes.

The poem does not condemn the killings. Nor does it endorse them. The narrator characteristically shows us multiple different perspectives on the action. Odysseus and Telemachus view these killings as necessary to restore their honour, and Athena, the divine lover of spoils, delights in their bloody triumph. But we are also shown what it feels like for the women, with their hopes of life and homecoming ended, like their lives.

As a final example, let’s look at the opening lines of the poem, known as the proem. This passage is one of the most challenging for the translator, not least because it is one of the most iconic passages of ancient literature. It sets a tone, a mood – and yet it is also different in style from much of the poem, with its long, meandering sentence structure and its allusive references to parts of the story to come.

> ἄνδρα μοι ἔννεπε, μοῦσα, πολύτροπον, ὃς μάλα πολλὰ
>
> πλάγχθη, ἐπεὶ Τροίης ἱερὸν πτολίεθρον ἔπερσεν·
>
> πολλῶν δ᾽ ἀνθρώπων ἴδεν ἄστεα καὶ νόον ἔγνω,
>
> πολλὰ δ᾽ ὅ γ᾽ ἐν πόντῳ πάθεν ἄλγεα ὃν κατὰ θυμόν,
>
> ἀρνύμενος ἥν τε ψυχὴν καὶ νόστον ἑταίρων.
>
> ἀλλ᾽ οὐδ᾽ ὣς ἑτάρους ἐρρύσατο, ἱέμενός περ·
>
> αὐτῶν γὰρ σφετέρῃσιν ἀτασθαλίῃσιν ὄλοντο,
>
> νήπιοι, οἳ κατὰ βοῦς Ὑπερίονος Ἠελίοιο
>
> ἤσθιον· αὐτὰρ ὁ τοῖσιν ἀφείλετο νόστιμον ἦμαρ.
>
> τῶν ἁμόθεν γε, θεά, θύγατερ Διός, εἰπὲ καὶ ἡμῖν.

I’ll comment here on some of the most widely read modern translations of this passage. First, the version by E. V. Rieu, revised by Peter Jones (1946/1991), which is still commonly read in the UK, although it is less popular in the US, where free verse translations are dominant.

> Tell me, Muse, the story of that resourceful man who was driven to wander far and wide after he had sacked the holy citadel of Troy. He saw the cities of many people and he learnt their ways. He suffered great anguish on the high seas in his struggles to preserve his life and bring his comrades home. But he failed to save those comrades, in spite of all his efforts. It was their own transgression that brought them to their doom, for in their folly they devoured the oxen of Hyperion the Sun-god and he saw to it that they would never return. Tell us this story, goddess daughter of Zeus, beginning at whatever point you will.

I quite like ‘resourceful’ for *polytropon* (from *polytropos*), although it conveys nothing of the original’s implicit metaphors of turning and being turned; it would work far better if the epithet in the original had been *polymēchanos*. In some places, the translation is very expansive: for instance, the original has just three words for Odysseus’s wanderings – *mala polla plagthē* – where Rieu has eight: ‘was driven to wander far and wide’. The addition of ‘was driven’ removes an important ambiguity in the original: did Odysseus have any choice about his wanderings? The ‘high seas’ give a rollicking sense of adventure, although the original has no modifier for the sea. Rieu’s prose characteristically uses a number of wordy phrases and abstract nouns where the original has finite verbs and participles: for instance, ‘in his struggles’ translates a participle (*arnumenos*) as does ‘in spite of all his efforts’ (*hiemenos*). In the Greek, the men straight up ‘died’ (*olonto* – a very common word for dying), while in this translation, their transgression ‘brought them to their doom’. The effect is a more distanced, less direct narrative than the original. High, quasi-biblical diction (‘anguish’, ‘doom’, ‘folly’, ‘transgression’) sits a little uneasily with colloquial business-speak (‘saw to it’, ‘whatever point’).

Richmond Lattimore’s version in free verse is even more verbose – far more so than the Greek.

> Tell me, Muse, of the man of many ways, who was driven
>
> far journeys, after he had sacked Troy’s sacred citadel.
>
> Many were they whose cities he saw, whose minds he learned of,
>
> many the pains he suffered in his spirit on the wide sea,
>
> struggling for his own life and the homecoming of his companions.
>
> Even so he could not save his companions, hard though
>
> he strove to; they were destroyed by their own wild recklessness,
>
> fools, who devoured the oxen of Helios, the Sun God,
>
> and he took away the day of their homecoming. From some point
>
> here, goddess, daughter of Zeus, speak, and begin our story.

The seventy-four words of the original become 109 words in Lattimore – a fairly characteristic ratio of expansion. Lattimore’s phrasing is often a long way from normal English, even when the original is quite ordinary within the idioms of Homeric Greek: no native English speaker, except a translator, would have written ‘was driven / far journeys’, or ‘struggling for his own life’. Lattimore adds a noun, ‘journeys’, when there is none in the Greek, and like Rieu, he interprets *plagthē* to suggest that some external force has ‘driven’ Odysseus: the Greek verb is passive in form, but is typically used in the passive to mean ‘wander’ or ‘drift’. Lattimore’s protagonist is fundamentally inactive, and the translator undermines Odysseus’s cognitive achievements as well: the Greek of *nöon egnō* suggests that he knew or understood the minds (or habits) of many people – but Lattimore’s Odysseus only learns ‘of’ them, which doesn’t indicate any particular intelligence. This translator, as is typical of his approach, adds repetitions where the original has none: here, for instance, there is the awkward repetition of ‘of’ with different senses and different stresses in the line (‘of the man’, ‘of many ways’, ‘learned of’). The line breaks are markedly peculiar and off-putting; it is hard to understand, for instance, why Lattimore breaks the line at ‘hard though’, when the translation is using no metrical constraints and the Greek includes the whole participle phrase before the line break (*hiemenos per*). Lattimore skips Hyperion, explains who Helios is, and adds ‘wild’ – choices that arguably make the men more idiotic, and their leader more caring, than they are in the Greek. The awkwardness of phrasing and the strange lack of fluency give a very different overall impression than does the vivid, rhythmical language of the original. And yet Lattimore’s approach to translating Homer, in long, unmetrical, unidiomatic English lines, has been paralleled by numerous other late twentiethand twenty-first-century translators, several of whom have differed mostly by being even more verbose.

Daniel Mendelsohn’s 2025 translation begins, ‘Tell me the tale of a man, Muse, who had so many roundabout ways / to wander, driven off course, after sacking Troy’s hallowed keep.’ Fourteen words in Greek have become twenty-four in English, through the addition of words and phrases that correspond to nothing specific in the Greek, though they often draw on the phrasing of earlier English translations: ‘the tale’ is an addition also found in the 1929 translation by Herbert Bates; ‘off course’ is a nautical phrase, not corresponding to anything in the Greek but also found in Robert Fagles’ version, and in tune with the modern misperception of the poem’s subject as a set of maritime misadventures; ‘ways’ expands the original epithet *polytropos* and is also found in the Loeb translation and Lattimore. Following Lattimore in his courageous defiance of contemporary English idiom, Mendelsohn presents Odysseus as if he were enduring a journey very much like driving through Milton Keynes – a nauseating and banal passage through one traffic circle after another.

The version by Robert Fitzgerald (1961) is far more elegant, and written in what is recognisably verse (using a largely iambic rhythm, although with many variations).

> Sing in me, Muse, and through me tell the story
>
> of that man skilled in all ways of contending,
>
> the wanderer, harried for years on end,
>
> after he plundered the stronghold
>
> on the proud height of Troy.
>
> He saw the townlands
>
> and learned the minds of many distant men,
>
> and weathered many bitter nights and days
>
> in his deep heart at sea, while he fought only
>
> to save his life, to bring his shipmates home.
>
> But not by will nor valor could he save them,
>
> for their own recklessness destroyed them all –
>
> children and fools, they killed and feasted on
>
> the cattle of Lord Hêlios, the Sun,
>
> and he who moves all day through heaven
>
> took from their eyes the dawn of their return.
>
> Of these adventures, Muse, daughter of Zeus,
>
> tell us in our time, lift the great song again.

Many of the most charming details of this translation are entirely the invention of the translator, including the lovely ‘in me … through me’, the ‘story’ (reflected by Mendelsohn’s ‘tale’), the ‘dawn’ of their return (rather than ‘day’), the notion that Odysseus could not save the men ‘by will nor valor’, ‘proud’, ‘distant’, ‘killed and’, ‘Lord’, ‘he who moves all day through heaven’ (a wonderful addition), ‘took from their eyes’ (the Greek has nothing about blinding or sight), ‘adventures’ (a very modern idea of what the *Odyssey* is about), and ‘lift the great song’ – a beautiful echo of the Hebrew psalms, as translated in the King James Bible, imported into an entirely different ancient text. Fitzgerald is not afraid to use peculiar word choices, even when the Greek lexicon is very ordinary; for instance, the normal word for towns, *astea*, becomes ‘townlands’, and the vague statement that Odysseus suffered a great deal on the sea (*polla d’ho g’en pontōi pathen algea*) takes on new specificity in Fitzgerald: ‘weathered many bitter nights and days’. The translation is very expansive, such that the two Greek words *andra ... polytropon* are rendered by eleven English words: ‘the story / of that man skilled in all ways of contending’. It is very hard to see how ‘contending’ can be got out of the Greek, although of course it does convey one of Odysseus’s specialities. As English verse, I personally like Fitzgerald more than most of the modern British and American translations, because he is attuned to rhythm and the possibilities of the English language, in ways that many contemporary classicists are not. At the same time, the fine literary artifice – the clever, original phrasing and the dense allusions to earlier literature – are out of keeping with the oral poetics of the original.

The translation by Robert Fagles into free verse begins,

> Sing to me of the man, Muse, the man of twists and turns…
>
> driven time and again off course, once he had plundered
>
> the hallowed heights of Troy.
>
> Many cities of men he saw and learned their minds,
>
> many pains he suffered, heartsick on the open sea,
>
> fighting to save his life and bring his comrades home.
>
> But he could not save them from disaster, hard as he strove –
>
> the recklessness of their own ways destroyed them all,
>
> the blind fools, they devoured the cattle of the Sun
>
> and the Sungod blotted out the day of their return.
>
> Launch out on his story, Muse, daughter of Zeus,
>
> start from where you will – sing for our time too.

The Fagles translation is very loud, lively and chatty, so it is not surprising that it has remained a bestseller in the US. It makes Homer into easy reading. The translation is frequently far longer than the original, including repetitions where the original does not repeat (‘the man … the man’), and often giving a little extra pep by adding contemporary American idioms and imagery that make this alien, very ancient poem feel familiar: ‘twists and turns’, ‘time and again’, ‘off course’, ‘heartsick’, and ‘wiped out from sight’ (borrowed from Fitzgerald). None of these images and phrases correspond to anything in the original. Fagles has a reputation for being a much looser translator than Lattimore, and there are details here that might confirm this view: for instance, the Greek suggests ‘cities of many men’, not ‘many cities of men’. More substantially – not necessarily wrongly – Fagles often amps up the emotional stakes, adding melodrama or sentimentality or intensity that is hard to find in the Greek. He uses ‘devoured’ as a translation for the normal word for ‘eat’ (*ēsthion*). Similarly, a favourite Fagles word is ‘disaster’, which corresponds here to nothing in the Greek but commonly recurs in his text: he constantly reminds us that the stakes are high. I like the use of ‘sing’ at the beginning and end of the passage, creating a nice ring composition – but the Greek *ennepe ... eipe* is a variation of two distinct cognate verbs, both of which suggest ‘say’, not ‘sing’, which is a different verb. ‘Blind fools’ introduces a metaphor that isn’t in the Greek (*nēpioi* are ‘fools’ or ‘childish’, but not literally or metaphorically ‘blind’), and again, Fagles’ debt to Fitzgerald is clear. I like ‘launch out’ for the embarking of the poem, but it is entirely made up by Fagles (there is no ship metaphor in the original). More importantly, adding ‘his story’ for words that more literally suggest ‘of these things’ is a debatable choice: Fagles frames the whole poem as the story of a single individual, ‘him’, which the Greek does not do (and instead, the Greek shows us the intertwining of several distinct people’s stories, and their varying degrees of success in finding and achieving their journeys home, their *nostoi*).

Finally, the Greek *kai hēmin* literally suggests ‘also to us’: Fagles has borrowed ‘our time’ from Fitzgerald. The borrowings of Fagles from Fitzgerald and Lattimore (and then of Lombardo from all three) are visible on every page, and are, of course, valid. There’s no rule to forbid a retranslator from lifting a phrase from earlier translators. But these inheritances are worth noting, because if you have not read the original it may not be clear that these different translators are heavily dependent on each other, rather than each offering an independent interpretation of the original. And yet, despite Fagles’ borrowing, the reading experience of the Fitzgerald and Fagles translations is very different. Fitzgerald’s version is allusive and ornately literary, in a high modernist mode. Fagles is more grandiose, more Whitmanesque. In translating an ancient epic, he goes for intensity. The ellipses (…) are one of Fagles’ favourite ways to build suspense – a typographical device that is, of course, alien to the original, which was experienced primarily in oral performance and written for many centuries with no punctuation at all, but which fits well with American late twentieth-century assumptions about what ‘epic’ poetry means.

Stanley Lombardo’s slangy, unmetrical free verse translation borrows heavily from earlier American translations, especially Fagles. But it is one of the boldest in stripping out details from the Greek, and adding elements that are not, strictly speaking, paralleled by the original.

> SPEAK, MEMORY –
>
> Of the cunning hero,
>
> The wanderer, blown off course time and again
>
> After he plundered Troy’s sacred heights.
>
> Speak
>
> Of all the cities he saw, the minds he grasped,
>
> The suffering deep in his heart at sea
>
> As he struggled to survive and bring his men home
>
> But could not save them, hard as he tried –
>
> The fools – destroyed by their own recklessness
>
> When they ate the oxen of Hyperion, the Sun,
>
> And that god snuffed out their day of return.
>
> Of these things
>
> Speak, Immortal One,
>
> And tell the tale once more in our time.

The opening salvo, ‘Speak, Memory’, is a quotation from Nabokov (*Speak, Memory* is the title of the novelist’s memoir) – inviting us to view the poem as a creative autobiography, presumably of Odysseus, who is, like the emigré Russian writer, much travelled and prone to self-reinvention. Word choices familiar from Fagles that do not correspond to the Greek are easy to spot, including ‘off course’ and ‘hard’. Moreover, Lombardo draws on the imagery of Fagles in ‘blotted out’, slightly varying it as ‘snuffed out’ (‘Out, brief candle!’) – although no such imagery is there in the Greek. The grand ‘Immortal One’ is Lombardo’s invention, and he characteristically omits several details from the Greek, including the fact that the goddess is a daughter of Zeus. His rendition of *polytropon* as ‘cunning’ is enticing, although it seems to be more an evocation of the general theme of the poem than a translation of this specific word: other Homeric epithets used for Odysseus, such as *polymētis* (‘much-cunning’) or *polymēchanos* (‘much-devising’ / ‘much-problem-solve-y’) would be better translations for the English word ‘cunning’. The surprise of the Greek, in its use of an unusual descriptor for our familiar but ever-changing hero, is certainly not conveyed by Lombardo’s predictably iconic choice of ‘cunning’ for the mythical smart guy.

Finally, here is my own current translation, revised since my published 2017 version.

> Tell me about a complicated man,
>
> Muse, who was lost so long and fled so far,
>
> when he had sacked the sacred citadel
>
> of Troy – and how he saw and understood
>
> so many people and so many places,
>
> and suffered so much in his heart at sea,
>
> as he was struggling to save his life
>
> and bring his men back home. But even so,
>
> despite his efforts, he did not protect them.
>
> Poor fools! They died by their own wilfulness –
>
> they ate the cattle of Hyperion,
>
> the Sun, who took away their chance of home.
>
> Of these events now tell us also, goddess,
>
> daughter of Zeus. Begin from anywhere.

I hoped to recreate certain alien features of the original that aren’t reflected in most modern translations, including, most obviously, regular, traditional poetic metre. The original is dactylic hexameter, the traditional metre of narrative verse in archaic Greece, so – as noted earlier – I used the anglophone equivalent, iambic pentameter. I also wanted to recreate other poetic/sonic features of the original, such as alliteration (*polytropon ... polla ... plagthē, epei ptoliethron epersen / pollōn:* ‘fled … far’, ‘sacked … sacred … so … suffered’).

My aim, more broadly, was to evoke the energy and clarity and beauty and music and pacing of the original, avoiding both the flatness or awkwardness of the more ‘literal’ versions and the looser ones that tend to expand or riff on the original. I tried to think hard about how similar effects might be achieved by different linguistic means: it’s impossible, for instance, to start an English sentence with the object (‘man’, *andra*), unless you repeat it (as Fagles does), but I wanted to avoid extra repetitions so I put ‘man’ in the emphatic position at the end of the line, rather than emphatically at the beginning, to try to create a similar effect. I tried in general to avoid adding extra metaphors or adorning the narrative with modern English idioms, as these other translators have done. My translation may seem stark, but that perception depends on a comparison with other translations rather than with the Greek.

And yet it is easy for anyone who has read the Greek, including me, to pick on features of my translation that are markedly different from the original – even beyond the fact that none of the words are the same. I found it impossible, for instance, to replicate the line breaks of the original, in moving from a metrical hexameter to a metrical pentameter: the Muse had to be deferred to the second line, although I hated to do it. In my revised translation, I tried even harder to reflect the original’s emphasis on multiplicity (*polytropon ... polla ... pollōn ... polla*); but I remain not fully satisfied with my current solution, which entails repeating the adverbial ‘so’. Translation, even more than most writing, takes dozens or hundreds of drafts, even when the translator has been reading the original text for decades before even beginning to consider how to English it. There’s no such thing as ‘the’ right answer, and numerous different translations, including all of these, can provide valid but different portraits of the original. I hope my translations allow readers to engage in new ways with the complexities, humanity and depth of Homer.

As a final reflection on my own translation, let’s look at just one word from this passage – the one over which many gallons of journalistic ink have been spilt: *polytropon* (from *polytropos*). Most Homeric characters have a small number of standard epithets, which can fit metrically with the name in different positions in the line. Achilles is ‘swift-footed’ and ‘son of Peleus’. Agamemnon is ‘lord of men’ and ‘son of Atreus’. Odysseus has more formulaic epithets than most, and a great many of them have to do with his multiplicity. He is a man of ‘many strategems’ (*polymēchanos*), ‘much wiliness’ (*polymētis*), ‘much-enduring’ (*polytlas*), ‘much-smarts’ (*polyphrōn*). He’s also ‘city-sacker’ (*ptoliporthos*) – an epithet shared with several other warriors – ‘resplendent/glorious’ (*dios*), ‘related to Zeus’ (*diogenes*), ‘godlike’ (*theoeides*, *theoeikelos*), ‘son of Laertes’, and more.

So the poet of the *Odyssey* had a choice about how to describe the protagonist of the poem in the first line. Why choose a relatively unusual epithet, *polytropos* ‘much-turny’? Why not choose one of those that focuses on Odysseus’s intimacy with the gods, or one that focuses on his famous strategic intelligence, or his capacity for patience and endurance, all of which will be essential in the poem? These sets of epithets are far more common in the poem as a whole, but they are not what we get in line one.

I am very far from the first reader to think that the choice of this unusual epithet must be marked, and that it serves as a promise about the forthcoming poem as well as about the protagonist and his journey. This choice of epithet assures us that not only the man but also the epic itself will feature numerous twists and turns, and many contrasting, overlapping scenes of almost-homecoming, almost-arrival and almost-recognition, even after our hero comes back to Ithaca. Multiplicity, tricks and changes will be central to the story, and the first line hints at this enticing fact, while also – appropriately for the theme – keeping us in the dark about the specifics of these mysteriously, enticingly numerous narrative ‘turns’.

In later Greek, the word can be applied to situations as well as to people, and it often seems to have negative connotations. Thucydides uses the word for multiplicity of situations in life, in the Periclean Funeral Oration (2.44): *en polytropois gar xumphorais epistantai traphentes* (‘They know that they were brought up amid manifold circumstances’). It is used of a dangerously complicated or changeable disease (Plutarch, *Numa* 24: an evil king was cured of his impiety by a ‘serious and complicated illness’) and of war. A rendering that could only apply to the man and not the poem or the trip did not seem adequate. A man can be ‘crafty’. A poem or a journey can’t. A trip or a poem (or a war, a disease or a circumstance) cannot be ‘wily’, which is a fine rendering of *polymētis*, but not of *polytropos.*

*Polytropos* isn’t necessarily positive, at least in later uses. Plutarch applies it to the notorious turncoat, Alcibiades, in his biography of the same name. Plato’s discussion of the relative moral merits of Homeric heroes (in *Hippias Minor* 364e) contrasts the ‘very simple and very truthful’ Achilles (*haploustatos kai alēthestatos*) with Odysseus as ‘complicated’, *polytropos*. Plato’s usage suggests that to him, at least, *polytropos* definitely doesn’t mean ‘wise’, because it is distinct from Nestor’s quality of *sophia*. Of course, Plato was writing a good three centuries after the composition of the Homeric poems; there is no reason to assume that the values of later prose authors will be identical with those of the original *Odyssey*. But these later uses do give some inkling of how at least some ancient readers might have taken that epithet.

It’s also important that *tropos* suggests way of life, custom, habit, guise, manner or character, as well as, literally, ‘turn’. Arguably, the epithet anticipates the ways Odysseus will appear in many disguises, will tell numerous false autobiographies, and will succeed in code-switching, transforming himself to fit in with entirely different social worlds and environments with each island he visits. He can be and behave as many people, or nobody. This variability is an extraordinary and essential element of his heroic excellence, and it is not the same as his other extraordinary qualities. You could be great at solving problems and coming up with solutions to transform your environment for survival (*polymēchania*), as Odysseus does with the wooden horse, and with the raft on which he escapes the island of Calypso, and great at enduring against tough odds for a really long time without giving up (*polytl*a*s*), without also being able to transform yourself into multiple guises and roles (*polytropia*). I needed to think through those connotations and distinctions to find the right word.

I was also keen to try to honour the pacing of the original. I confined myself to the same number of lines as the Greek. I did not want to produce a translation that was longer or wordier, or that risked being flabbier than the original. For that reason, I was reluctant to do what many translators have done: to render this single four-syllable word with a subordinate clause or a phrase, although I did play around with ways of doing it like that. ‘A man who was turning and turned’. ‘A man of many turns’. But those options have real costs, because the gripping pace and drive of the opening is lost as soon as you start shoving a many-word phrase into the first sentence. I wanted to translate a whole poetic and narrative experience, not write the explanatory footnotes as if they were the text. None of the options using explanatory phrases or clauses seemed to me to match the impact of the original, with the startling arrival of this powerful, unusual epithet in the middle of the line, after we’ve already had the noun. Moreover, ‘a man of many turns’ is more or less incomprehensible, certainly not vivid – and there is no reason to think that the original was difficult to understand. In English, ‘turns’ does not carry the connotations of many disguises or habits or characters. It is literal but unfaithful, in the sense that it doesn’t make clear what is clear in the original. There’s also potential for an unfortunate recollection of Austin Powers, International Man of Mystery. I also didn’t want to introduce syntactical repetitiveness where the original is varied. I tried out, but then ruled out, many variations on ‘a man who turned/was turned a lot, who also wandered a lot’ – the original has only one relative clause and distinguishes between the primary quality of the *polytropia*, introduced in the main clause, and the subordinate clause account of the numerous wanderings.

I spent many hours, days and weeks searching around for alternatives. I eliminated ‘twisty’, which is great for an airport novel or a corkscrew, but not plausible for a person (and ‘twisted’ would be unfortunate, as would ‘kinky’ or ‘perverted’ – those are all the right metaphor, but the wrong connotations). ‘Topsy-turvy’ seems appropriate for a children’s TV show, not an epic. ‘Circuitous’, or ‘zigzag’ or ‘meandering’ might work for a journey, but not so well for a person, and ‘meandering’, a lovely word, runs into the alliteration problem – there is already too much inevitable alliteration (‘man … me … Muse’), which also rules out all cognates of ‘movable’ or ‘mobile’, which also fail to connote movement that’s not straight; Odysseus’s movements are far more varied. ‘Flexible’ suggests yoga. ‘Turned’ sounds like spoiled milk. ‘Versatile’ seemed like an option for a while, but it is boring and does not work well to connote the actual travel or the poetics of poem, as opposed to the character. And besides, ‘a versatile man’ does not scan in an iambic line, so it would have required some syntactical contortions (‘a man of versatility’ – a terrible, clunky mess).

It would be fun to use ‘translated’, like Shakespeare’s Bottom. That would have made for a nice piece of homage to the Latin translator, Livius Andronicus, who used *versutus* for his mostly lost Latin verse translation of the *Odyssey*. I was tempted by that option for a while, because I liked the idea of those layers of allusion and homage, paralleling the metapoetic connotations of the original. But it would have been a solution that most readers would find more confusing than illuminating, and I did not want to suggest anywhere, let alone in the first line, that the *Odyssey* is a cleverly allusive, literary text. The Homeric poems are based on an oral tradition, they are not difficult Greek, and layered, self-consciously literary allusions, are completely alien to Homeric quasi-oral poetics. As a translator of Homer, it isn’t my job to try to be clever. That was certainly part of my job as a translator of Euripides or Seneca, but not Homer. Homeric poetry needs to sound traditional and in a sense entirely artificial – hence my use of very regular and very traditional metre – but not allusive or markedly literary. I wanted the translation to be stylized, rhythmical and traditional in verse form, with some elements of grandeur or majesty, able to mutate for a range of different registers and moods, but also to feel fresh, as if it had sprung from the spoken language of the people, whatever that means in contemporary English. So, no ‘translated’, and nothing too fancy. It needs to be a real word, in regular speech – and yet somehow surprising.

So I went with ‘complicated’, which suggests something of the imagery (folding or layers, which are analogous to turns) and has the same syllable count as the original, and is a real, not made-up, English word, conveys immediate meaning, as the original does, but is appropriately multiple, and hints at truths to come, about the character, the poem and the trip. It is direct and comprehensible, as the original is, and it is also, like the original, an injunction to watch out for complexity in unexpected places. This word choice is potentially a shock, not quite what you expect at the start of an epic poem – which also feels right, given that the original is an unusual and surprising word choice.

I like the concept of complexity as a positive quality in the world of this poem and this protagonist, and for setting the mood for the rest of the poem and the translation. In teaching Homer to undergraduates I have seen that students frequently assume that very old poems will have simple morals, simple psychology, and simple heroes, regardless of the translation. I liked ‘complicated’ as a way of reminding the reader right away to reconsider that assumption. The word ‘complicated’ is itself ostensibly simple, like the narrative of the *Odyssey*, and like Homeric syntax, narrative and poetics. This poem tells a story of a man going home. But there are so many layers and disguises beneath.

I have sometimes been scolded for the choice of ‘complicated’. Sometimes it’s by people who have read only the first line, and none of the rest of the translation. Sometimes it’s by people who say that they like everything about the translation except ‘complicated’. Bless them.

I commonly hear two objections.

One is that some readers seem to think that it’s negative, which is quite an odd response as far as I can see. The word does not, to my ear, have connotations that are either definitely positive or definitely negative. It’s certainly less negative than other options, such as ‘kinky’ or ‘turncoat’. There is nothing wrong with being complicated! We all are! I am, for sure, and I don’t see it as a bad thing. It’s far less negative than Plato’s usage of *polytropos* would suggest – I would be more convinced by an argument that it’s not negative enough. But I did not want to go all-out negative, because I don’t think the original justifies that. Complexity, in a poem or narrative, or a mythical character, is surely all to the good. I see the original, and my translation, as a promise, or even an enticement: ‘Dear Listener, stay with me, because you won’t be bored by this character or this poem.’ Who doesn’t love disguises and schemes? Who doesn’t love the tale of a long con? The narrator is promising us, implicitly, that we’ll get an inside scoop on a character whose many layers, turns, names and disguises won’t be visible to everyone he encounters. Uncomplicated characters are a hard sell, if you want the adult listener to stay with you for many hours of story. Complexity, sign me up. I am not the least bit original in seeing the Homeric Odysseus as a complex and multilayered character, who arouses our intense interest and intense empathy, and who is viewed in very different ways by different characters throughout the poem, because he contains multitudes. Homer’s Odysseus is a distinct and far more appealing character than the often simpler and often more purely evil Odysseus we find in some other ancient sources (like the scheming sophist of Sophocles’ *Philoctetes*, or the cruel Ulysses of the *Aeneid*). To me, ‘complicated’ does not suggest either ‘good guy’ or ‘bad guy’: it is rather a promise that this poem will not stoop to those implausible simplifications.

Some people seem to be very touchy about ancient characters. If people want ‘heroes’ who are entirely sympathetic, or ethically uncomplicated, and who would never let anyone die under their command, daytime soap operas may be a better bet than Homer.

The second issue for some readers is the idea that ‘complicated’ sounds ‘too modern’. The word ‘complicated’ isn’t particularly modern in English (*OED* cites 1656 as the first known instance of the modern meaning). But maybe ‘complicated man’ has been on the rise (Google Ngram tells me that that phrase, and ‘complicated relationship’, have risen in popularity since the turn of this century). Maybe for some people it has resonances of a relationship status on Facebook, or, better, Avril Lavigne. I like the Lavigne lyrics for ‘Complicated’ as a text with a kind of resonance with the *Odyssey*: *‘*acting like you’re somebody else’ is a central feature of Odysseus’s *polytropia*, and it’s essential to how and why he survives. If you do hear the song in the line, maybe it helps suggest the connotations of ‘many guises’ that are there in the original word. Sometimes you do have to make everything so complicated, sometimes you gotta wear your preppy clothes and strike a pose (or at least get your multiple goddess makeovers) if you want to survive as the warrior king of Ithaca.

For full disclosure: I tried to rewrite the whole passage at a very late stage, once I learned about the opening of the film *Shaft*, which I had not seen: the theme song by Isaac Hayes includes the line, ‘He’s a complicated man / but no one understands him but his woman.’ I thought the possibility of that unintended allusion might mean that I had to throw out my draft. After weeks of attempting to rewrite, needing to rewrite everything else once that word was different, and making the whole proem flabbier, less vivid, more awkward, and all around worse every time, I realized that there was no better option – and that, actually, I quite like the *Shaft* intertext. Samuel L. Jackson would make a great Odysseus. The first line of the epic is not explicitly about the protagonist’s complicated marriage, but that topic will prove essential in the poem to come.

I sometimes worry that ‘complicated man’ suggests something too internal, too psychological. But I also know that one can’t avoid anachronistic connotations, in the inherently anachronistic process of translating from Homeric Greek to English, or indeed any modern language. It’s a compromise, as is every translation choice ever. The question is how to choose the least bad compromise.

Is ‘complicated’ exactly the same as *polytropos*? No, of course not. Does it correspond in a lot of important ways, and perform many of the same functions in the sentence and the verse paragraph? Yes. Can I think of a way to improve on it? After many years of pondering the question, I’d still say: no.

If I live another twenty years, and retain the capacity to read, and if the world is still habitable by humans, I hope to see younger people come up with much better solutions than mine. I also suspect that we will have more important things to worry about by then.
