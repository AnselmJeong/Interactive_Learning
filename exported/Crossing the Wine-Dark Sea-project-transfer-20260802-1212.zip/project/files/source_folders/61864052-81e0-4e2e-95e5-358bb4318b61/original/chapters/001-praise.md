# Praise

‘Emily Wilson’s brilliant reconsiderations of the ancient world – through the figure of Helen of Troy, the remaking of the *Iliad* by Christopher Logue, the use of comedy to grapple with dark matters, even slavery, and much besides – makes this an enthralling and profoundly relevant book’

Salman Rushdie

‘I adored reading these joyful, illuminating and engrossing journeys through ancient literature. With wit, passion and clarity, she invites us into each of these fascinating subjects. The final essay especially is required reading for anyone interested in translation, drawing back the veil on how a brilliant scholar and writer approaches her work’

Madeline Miller

‘Emily Wilson unlocks the gates to ancient Greece and Rome: her deep understanding of translation is the key’

Peter Stothard

‘By turns witty, stylish, ethical and pugilistic, Wilson reveals herself to be as brilliant an essayist as she is a translator’

Tim Whitmarsh

‘Wilson has produced a passionately personal – and at times polemic – celebration of language and the power of literature to speak across millennia’

David Stuttard

‘Vaulting from the ancient to the modern and back again, this collection is erudite, insightful and provocative. An unparalleled insight into the work of a classicist and translator at the height of their powers’

Paul Cooper

‘We’re incredibly lucky to have Emily Wilson writing about the art, politics and ethics of translation and retranslation. *Crossing the Wine-Dark Sea* is an impressive display of Wilson’s expertise, conviction and wit’

Jen Calleja
