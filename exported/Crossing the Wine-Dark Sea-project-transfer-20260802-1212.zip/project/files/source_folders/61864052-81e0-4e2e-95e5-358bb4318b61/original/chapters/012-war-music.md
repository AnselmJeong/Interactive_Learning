# War Music

Some of the most interesting reinventions of ancient literature have been created by non-classicists, who may be able to approach the material with the fresh eyes of an outsider. Perhaps the most powerful example is Christopher Logue’s *War Music* – a powerful poetic reimagining of the *Iliad* that manages to bring the vivid similes and divine epiphanies of the Greek original to a startling, dazzling new life.

As a child, Logue had a habit of petty theft. In his memoir, *Prince Charming*, he reveals that he stole money from his parents, then sweets from the local shop, and later pornographic magazines. He once robbed a little girl of her ice cream at toy-gun-point – a crime that resulted in his being sent miserably away to boarding school. But perhaps the most characteristic of Logue’s boyhood crimes was that he secretly wrote his own name at the end of a fair copy he made of Rudyard Kipling’s poem, ‘Gunga Din’, as if he himself were the author. Logue went on to make a wonderfully idiosyncratic literary career founded on the practice of poetic theft. The biggest and most extraordinary heist is his haunting, capricious patchwork of poetic narratives based on Homer’s *Iliad* – a grand larceny made all the more extraordinary by the fact that the thief knew no Greek at all, so he should have had no way to break into the crypt. Virgil, so legend has it, was accused of stealing from Homer when he began work on the *Aeneid*. He replied that it is easier to steal Hercules’ club than to steal a line from Homer. Any hack versifier can write Audenesque pontifications, but it is a tall order to remake Homer into a contemporary idiom, and Christopher Logue seemed, on the face of it, entirely ill-equipped for this mission impossible.

He came from a modest background (his father was a post office worker), and he had no university education (though he liked the idea of Oxford in theory). After an unhappy and alienated adolescence in an Irish Catholic boarding school, where he was disliked and beaten (Logue was a lifelong atheist) and performed fairly badly academically, he joined the army, lacking any better ideas about what to do with his life. At the end of his service, he was court-martialled and imprisoned for two years, for possession of stolen pay books. The crime seems to have been a half-conscious attempt to get himself kicked out of the army, in what he himself describes as a mixture of masochism and spite.

Logue’s life after prison was peripatetic. He spent some years in Paris, and made friends with various eminent literary people, including the elderly Beckett. On his return to England, he became active in the nascent campaign against nuclear arms, and was briefly imprisoned. He published poems in journals like the *TLS* and in a couple of books, churned out a pornographic novel, *Lust* (for which he was paid $1 a page), wrote some screenplays, adapted Pablo Neruda’s ‘Twenty Love Poems’ and combined them with a jazz track by Tony Kinsey on the wonderful record ‘Red Bird’, and appeared in several films as an actor, including as Cardinal Richelieu in Ken Russell’s *Devils*.

One of Logue’s main life goals was to avoid anything like an actual job. He succeeded, and his ramshackle series of projects, whims, friendships and fads all seem to have played their part in the construction of his major work of literary plunder, which has, at times, a jazzy rhythm, an improvisatory feel, a cinematic sensibility, awkwardness, an ambiguous, perhaps incoherent attitude towards war, a fetishistic love of detail, some idiosyncratic silliness, and a willingness to pause at odd moments and notice the unexpected.

Logue died in 2011, with the Homer project still not quite finished. But finishing was never really the point, since Logue takes little hints and nuggets here and there from Homer – he never aims for a complete retelling. The various volumes, along with the fragments of an ending, were eventually published together in 2016 as *War Music*, tastefully edited by the poet Christopher Reid. The collection includes an Appendix of Logue’s notes towards the final volume, ‘Big Men Falling a Long Way’, which consists of ‘fragments’ based on books 10–24, and ends with the meeting of Priam and Achilles, from *Iliad* book 24.

*War Music* is Logue’s Homer in as complete a state as it will ever be, and it is cause for celebration. Logue’s individual volumes, published earlier, have been bombastically hailed as ‘the best translation of Homer since Pope’s’ (Gary Wills), and the word ‘genius’ has been bandied around by several critics, including George Steiner. Logue’s ‘account’ of Homer is imperfect, but it has far more moments of startling brilliance than anybody could reasonably expect. Logue had no particular interest in Homer until he was asked by the classicist and translator Donald Carne-Ross in 1959 to produce a readable script version of *Iliad* book 16 for the BBC. *War Music* is not in any obvious sense a ‘translation’ of the *Iliad*, although it has a close relationship with it. Logue worked from existing translations and from cribs created for him by Carne-Ross.

Logue himself called it ‘my Homer poem’ or ‘an account of the *Iliad*’; he wanted to create a poem that was ‘dependent’ on Homer, but with a larger aim – to ‘revitalize narrative verse’. Logue’s *Music* does indeed have a music, based primarily on an iambic pentameter line, often broken up by shorter phrases by the effective use of line breaks. His work in film shows to powerful effect in the way he cuts between scenes, setting us instantly in one place, then changing the shot – a technique that allows for authentically Homeric sudden shifts between the worlds of gods and mortals:

> And with a wish He turned the fog to light,
>
> And with a word He called them back to Heaven. Sky.
>
> Snow.
>
> The 1000 yards.
>
> The palisade.
>
> Hector: ‘I am your Prince’.

The gulf between worlds is marked by a shift in verse form, and a change in the layout of the page – techniques that are, of course, absent from Homeric hexameter, which always scans the same way and implies no page on which to lie. But in his use of the sudden turn, the combination of speed and repetition, and the simple visual cues to shape a story, Logue makes us feel that he is in touch with some deep elements of the source text.

Logue’s quick-cutting technique also allows for heartstopping shifts between different time periods, a mode that again is at least reminiscent of Homer: ‘Go back an hour. / See what the Mousegod saw.’ The Iliadic narrative is concentrated on a short episode in a long war, but it zips back and forth in time, recalling, for instance, the original abduction of Helen in her re-abduction in Book 3, and anticipating the fall of the city in the final death of Hector. We are constantly reminded of the painful, chilling gap between the moments inhabited briefly by mortals, and the longer scope of time that is visible to the gods’-eye view of the world. Andromache prepares hot baths for Hector, not knowing that he is already dead. Helen looks from the wall of Troy for her brothers, not knowing that they are already in the ‘grain-giving’ earth of Sparta. Logue often reaches for this mode, as in the scene from Book 3, where Hector proposes a duel with Menelaus:

> ‘And if I die’ (this said within an inch of where he will)
>
> ‘My corpse belongs to Troy and to Andromache’.

The notion that a dead body is a thing that belongs to anyone (rather than being a person, to be treated honourably) is an anachronism, as is the notion of ‘my corpse’ (rather than ‘myself’): the Homeric dead are people, not husks of people. But the brevity of the parenthesis packs a Homeric punch. Sometimes Logue spells out this kind of resonant gap, as he does with Helen’s dead brothers: Helen thinks of them pulling off her covers in bed,

> and imagines that Troy is only a dream:
>
> But Troy was not a dream, and they lay dead,
>
> Killed by their neighbours in a hillside war,
>
> Beneath the snowy sheep that graze on Sparta.

This is far more detail about the brothers’ death and about Helen’s state of mind than we are given by the Homeric original. But there is something unexpectedly Homeric in the temporal and spatial confusion, the glimpse of a world opening up, to acknowledge that Troy is not the only war, and that wars may be entirely trivial, fought on a ‘hillside’ for no reason worth mentioning.

The most obvious way that Logue jumps across the passage of time is in his use of flagrantly anachronistic similes. These are sometimes gimmicky, and they do not always come off: ‘blood like a car-wash’ feels oddly predictable (there are too many car park and car-wash references in Logue); ‘as many arrows on his posy shield / As microphones on politicians’ stands’ takes one in a tedious direction, as does the idea that looking into God’s eyes (‘when he is cross’) is ‘like running into searchlights turned full on’. Sometimes the modern references feel as if Logue has lost the plot; we do not need to be told that men crammed together in battle are ‘like shoppers’, or to have a reference to ‘Miss Heber’s Diary, 1908’. A sequence of references to later celebrities in battle (Richard III on Bosworth field, Marshal Ney under Napoleon) meanders through some dates and numbers culled from biographical sources (‘July 4th to 14th ’43, 700 tanks engaged’), to end up with ‘Back to today’ – er, yes please.

But for the most part, the anachronistic similes are extraordinarily powerful. As Hector steps out to fight (and, in Logue’s condensed time scheme, to his imminent death), the Greek army responds as one:

> Think of a raked sky-wide Venetian blind.
>
> Add the receding traction of its slats
>
> Of its slats of its slats as a hand draws it up.
>
> Hear the Greek army getting to its feet:
>
> Then of a stadium when many boards are raised
>
> And many faces change to one vast face.
>
> So, where there were so many masks,
>
> Now one Greek mask glittered from strip to ridge.

The terrifying use of ordinary experience to describe something extraordinary feels reminiscent of Homer, and Logue’s imagery, like Homer’s, suggests more than one point of comparison. Later, Logue manages to give us a dispassionate glimpse of Patroclus piercing a victim with his spear and hoisting him up from the throng of bodies, ‘As easily as later men / Disengage a sardine from a tin’. The original simile invokes a man sitting fishing on a rock, hoisting up a big fish on a line. Logue’s updated version retains two crucial elements in the source text: the comparison of the scene of human slaughter to an everyday peace-time activity, and the precise visual detail.

Anachronism is fun, and Logue allows one to share his enjoyment in creating a collage made up of pieces from different eras. But it also serves the purpose of not allowing us to think of this story as a distant, musty old classic. Anachronism sucks us in, even when the anachronisms take us all over the modern world:

> It was so quiet in Heaven that you could hear
>
> The north wind pluck a chicken in Australia.

Logue’s story takes place in a setting that is far bigger than that of Homer – big enough to accommodate our modern selves, and to implicate us in some of the most disturbing feelings, like the joy of being a half-naked recruit about to run into battle for one side or another:

> And here it comes:
>
> That unpremeditated joy as you
>
> – the Uzi shuddering warm against your hip
>
> Happy in danger in a dangerous place
>
> Yourself another self you found at Troy –

Logue convinces us that these selves are indeed part of us, not only by the modern details (the Uzi), but by the authority of the language. By contrast, one of his most annoying tics is the use of exoticising fake-Greek or fake- Aborigine names: Quibuph, T’lesspiax, Neomab, Pagif, Nain, Cumin, Tu, and far too many more. These made-up names locate us nowhere except in Logue’s own head, and they make one long for a well-sharpened blue pencil.

Much of Logue’s imagery has no particular Homeric antecedent, and the Appendix reveals that he often came up with similes without having a place to stitch them in; they sometimes threaten to take over the narrative, since the imagery can be the most interesting thing happening. Logue has similes within similes, and fluent lists of images that create their own kind of story:

> Consider planes at touchdown – how they poise;
>
> Or palms beneath a numbered hurricane;
>
> Or birds wheeled sideways over windswept heights;
>
> or burly salmon challenging a weir;
>
> Right-angled, dreamy fliers as they ride
>
> The instep of a dying wave, or trace
>
> Diagonals on snowslopes.

The careful account of patterns of motion, and the gradual realisation that the final figures are surfers and skiers, is both beautiful and satisfying – and the supposed point of comparison, Achilles’ divine horses galloping across the plain to Troy, is mostly forgotten. Logue sometimes uses Homer’s plot as a hanger on which he can dangle his own lyrical descriptions.

Many of the most powerful passages in *War Music* are not markedly anachronistic, but rely on a close attention to the observable natural world. The narrator assumes that we, like him, have noticed the colours of things, and everything is familiar, until, almost imperceptibly, it becomes disturbingly alien:

> On certain winter days the land seems grey,
>
> And the no-headroom left between it and the grey
>
> Masses of downthrust cloud fills with wet haze.
>
> Lines of cold rain weld mile on sightless mile
>
> Of waste to air. Floods occupy the state. And still
>
> The rains continue, grey on grey.

Homer’s natural-world similes – the lions, the shepherds, the cranes – operate in something of the same way, juxtaposing an inhuman, ‘natural’ mode of destruction, with that inflicted on humans by each other. On the other hand, there is a distinctly literary and un-Homeric artistry in Logue’s confusing, inverted syntax, and his fondness for surprising buried metaphors (‘weld’; ‘occupy’). His painterly or cinematic eye for colour has nothing to do with Homer – the Homeric poems, as Gladstone famously pointed out in 1858, have what may seem to modern eyes a strangely limited colour palette. Logue has several brilliant lists of colours, like the one at the start of the *War Music* volume *Pax*: ‘Rat. / Pearl. / Onion. / Honey’ – a mode of observation that could not be further than Homer’s. But it seems pointless to quibble over the ways that Logue’s descriptive mode is or is not ‘Homeric’. It is good, which matters more. These descriptions locate us in a world that is familiar but that we have never quite seen before, and the sound of words becomes the look of things:

> Blue grey, gold grey, blue gold,
>
> Translucent nothingnesses
>
> Readying our space,
>
> Within the deep, unchanging sea of space,
>
> For Hesper’s entrance, and the silver wrap.

For all his artfulness, Logue also knows the punch that simple words can pack. One of his most famous lyrics from his non-Homeric work is ‘Be not too Hard’, a ballad which was recorded as a song by Donovan and covered by Joan Baez. Logue’s achievement in this deceptively simple poem is to show us the absolute folly of young men who throw away lives that would be short enough anyway – while also reminding us more explicitly of the pointlessness of scolding them. Many of the strongest passages in Logue are apparently simple, authoritative, clearly phrased poetic statements about how the world is, how people are – sometimes in the mouths of the characters, and sometimes spoken by the narrator. Agamemnon declares, ‘Never forget that we were born to kill. / We keep the bloodshed to the maximum.’ We can see the horror of his perspective more clearly from its propagandistic clarity. These great sententious passages do not create a coherent world view (which is not the point of them), but they create a deep sense of longing for more certainty than the world could ever offer:

> Lord Thoal knows that people love to have a side –
>
> taking a side as simply as a god.
>
> And he himself would like to find a god
>
> who tapped his foot while humans danced.

Logue’s master-heist of Homer is combined with many miniature thefts from other poets, and the loot in his commonplace book provides some of the most resonant gnomic utterances. In the first volume, *Kings*, Nestor tells Achilles to back off his quarrel with Agamemnon: ‘You are part dust, part deity. / But he is King. And so, for Greece, comes first.’ Logue himself acknowledges, in the Eliotesque notes to *Kings*, that the first line here is stolen from Byron’s *Manfred*. But there are many other unacknowledged thefts paraded here, not least from Eliot himself, a poet whom Logue adored. Achilles’ deathless horses, telling the hero he will die, take on the voice of Eliot’s *Four Quartets*: ‘This time we will, this time we can, but this time cannot last.’ Logue pickpockets from everywhere, high culture and low – from Dryden and Tennyson, to the moment when Achilles, rejecting Nestor’s plea for him to return to battle, complains that there has been ‘No sign of love for me behind your tears’ (a clear allusion to the Paul McCartney song, ‘For No One’). When it works – which is surprisingly often, though by no means always – the multiple layers of quotation and allusion create a layered awareness of many moments in time, many pens and typewriters and computers, creating a single, truly epic story.

One might think that the hardest part about rewriting the *Iliad*, for an entirely unbelieving modern poet, would be the presence of the gods. But Logue’s divine epiphanies are sometimes astonishingly good. The first moment when Thetis becomes manifest to Achilles, at the start of the volume *Kings*, has a brilliant slow quietness that enables us actually to believe it when we are told how the scent of ‘oceanic lavender’

> Drew from the seal-coloured sea onto the beach
>
> A mist that moved like weed, then stood, then turned
>
> Into his mother, Thetis’, lovelost face.

‘Lovelost’ is a mistake, but the sense of a permeable membrane between two worlds is entirely convincing. More violent divine encounters and descents are often brilliantly done – Athena grabbing Achilles from the quarrel scene, Aphrodite whisking Paris away, or the wonderful sequence in the Patrocleia section when Achilles’ friend Patroclus pushes too far ahead, against divine orders, and reaches the wall of Troy. The narrator tells us that he ‘fought like dreaming’, and his inability to recognise the real divine presence may be half-shared by the reader, until we turn the page and find in a font an inch high: ‘APOLLO! Who had been patient with you’. The entirely un-Homeric semantics of typography are enlisted to force the modern reader, just for a moment, to become a total believer in the Olympians.

Apollo and Thetis are far more successfully rendered than the other gods, because Logue allows them to remain as alien beings – Thetis as a manifestation of the sea, and Apollo as the strange ‘Mousegod’, the brightness of sunlight. It is unfortunate and misleading to make Zeus into ‘God’, as Logue consistently does, and to suggest that ‘He’ is infinitely greater than the other deities. The Christianising serves no particular literary purpose, and weakens the more interesting Homeric sense of a world that is full of not one but many inhuman, not fully comprehensible and often hostile beings, whose purposes may contradict one another in unpredictable ways. Worst of all are the depictions of the three main Iliadic goddesses, Athena, Hera and Aphrodite, who are reduced to stereotypes from a sexist TV soap opera – ‘The Wife. The Daughter’, characterised primarily by their ‘creamy’ bodies, their ‘bums’ (there are far too many bums), and their clothes (‘both in black wraparound tops’). Athena is ‘Teenaged Athena’, an epithet that robs her of all power, purpose and strategic skill. Hera is the nagging wife of ‘God’, ‘Greek mad’, and bitter that Paris judged her ‘less / Nudely speaking’. ‘Giggling’ Aphrodite (‘Miss Tops and Thongs’) is rendered mostly by her affinity with 1970s fashion – ‘sparkling clogs’, ‘grey silk lounge pajamas’ paired with ‘snakeskin flip-flops’. The contrast between the high-stakes world of mortals, and the gods who can afford to be more frivolous, is an essential element of the *Iliad*. But Logue ruins the effect by making us feel that there is nothing to understand about these goddesses – they are made of cardboard. Homer’s deities are more than humans only in power, and less than humans only because they have no need of human modes of courage, patience and kindness; they are not less fully realised as people.

But Logue’s human people suffer from similar defects, albeit in less glaring ways – especially the female people. The use of the archaism ‘a she’ to refer to women as prizes of war might have seemed like a way to represent the Homeric elite warriors’ commodification of women – but Logue’s narrator also sees his women only as ‘she’s’. Helen, one of the most interesting and complex characters in the Homeric poems, becomes whiny and uninteresting, complaining predictably about her marriage troubles: ‘All I do is cry. And that is so annoying.’ Indeed it is. The problem, however, is not only that Logue cannot create a convincing female character, but that he has little interest in the experience of any individual character, male or female. He is good at stump-post speeches, but no good at dialogue, no good at grief, and has no deep interest in courage, patience, honour or human interaction. This helps explain why some of the most memorable and emotional moments in the *Iliad* – the tender parting of Hector and Andromache, or the Embassy to Achilles, in which the hero declares that no gifts and no amount of respect could be worth the loss of a single human life, which will never come back once it has crossed the ‘barrier of the teeth’ – become in Logue flat and forgettable. The choice of Achilles is framed in terms that feel totally unconvincing:

> My mother says I have a choice:
>
> Live as a happy backwoods king for aye;
>
> Or give the world an everlasting murmur of my name,
>
> And die.

The awkward, incoherent, and partly archaic phrasing suggests that Logue has not managed to feel his way inside the person who might face a choice like this. The final fragments towards Logue’s version of Book 24, the meeting of Achilles with old King Priam, who has come to his enemy’s tent to beg for the body of his son from his killer, are equally plodding. The original shows us how desperate the father would have to be to let his lips touch ‘the terrible, manslaying hands, that had killed so many of his sons’. Logue’s version is simple, but entirely lacking in impact – Achilles lets Priam climb up to him ‘and, kneeling, kiss his hands: / The hands that killed his son. / A pause’. It feels hard to care. There are no tears in Logue.

Homer shows us the violence of war, the brevity of human life, and the human yearning to have something that lasts longer – honour, or a place in music and memory. *War Music* has less interest in human grief or human yearnings, and almost no interest in glory; it treats war as a feature of the natural world, or the technological world, which might be the same thing. Individuals – their feelings, their families, their histories, their stories – matter relatively little. What is interesting are the colours, the way things move. This is a strange and surprisingly captivating way of bringing ancient words to life. Logue invites us to watch the Trojan War as if on a screen, intermittently irritated, but often mesmerised by the surprising beauty of the way the story is told. This is not always a pretty poem, and it is certainly not Homer – but then, smuggling the whole *Iliad* out of the vault of antiquity would have been a tall order. Even if Logue cannot bring us all Homer’s treasures, he certainly manages to get some good licks of his ice cream. *War Music* is a powerful achievement, and it invites us to turn back to Homeric poetry with a new eye for what Logue saw in it: the detail that is – like Achilles’ divine armour, in Logue’s Dylan Thomas-inspired phrase – bright enough to ‘scream against the light’, and ‘so violent it can be seen / Across three thousand years’.
