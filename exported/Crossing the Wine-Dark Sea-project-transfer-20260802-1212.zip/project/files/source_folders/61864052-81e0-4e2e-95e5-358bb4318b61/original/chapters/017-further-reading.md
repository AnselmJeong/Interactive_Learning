# Further Reading

This is a list of some of the poets, authors and texts cited in this book.

## Ancient texts, poets and authors

Note that many of the dates are debatable!

- **Aeschylus**. Athenian tragic poet, 525–455 BCE. Extant plays include the Oresteia (a dramatic trilogy which itself includes Agamemnon, Libation Bearers and Eumenides).
- **Apuleius**. African Roman writer and rhetorician, 124–175 CE. Author of The Golden Ass, also known as the Metamorphoses.
- **Aristophanes**. Athenian comic poet, 446–386 BCE. Extant plays include Frogs, Clouds, Acharnians.
- **Catullus**. Roman poet, 84–54 BCE.
- **Demosthenes**. Athenian orator, 384–322 BCE.
- **Epictetus**. Greek teacher of Stoic philosophy to mostly Roman elite students, 50–135 CE.
- **Euripides**. Athenian tragic poet, 480–406 BCE. Extant plays include Helen, Trojan Women, Medea and many more.
- **Galen**. Greek medical writer, 129–206 CE.
- **Herodotus**. Greek historian/ethnographer, 484–425 BCE. Histories.
- **Hesiod**. Archaic Greek poet, semi-legendary composer of Theogony, Works and Days, 600s BCE.
- **Homer**. Archaic Greek poet, semi-legendary composer of Iliad, Odyssey, 600s BCE.
- **Livius Andronicus**. Early Latin poet and translator, 284–204 BCE. Works are almost entirely lost.
- **Marcus Aurelius**. Roman emperor, 121–180 BCE. Author of Meditations, jottings focused on self-improvement.
- **Menander**. Greek poet of ‘New Comedy’, 342–290 BCE.
- **Ovid**. Roman poet of love and change, 43 BCE–17 CE. Extant works include Metamorphoses and Amores.
- **Plato**. Greek philosopher, 428–328 BCE. Extant works include Republic, Symposium, Phaedrus, Phaedo, Apology of Socrates.
- **Plautus**. Roman comic verse dramatist, from 200s–100s BCE. Extant works include Pseudolus.
- **Plutarch**. Greek biographer, essayist, philosopher, 40–125 CE.
- **Sappho**. Greek female lyric poet who lived on the island of Lesbos, 500s BCE.
- **Seneca**. Roman essayist, dramatist, philosopher, 4 BCE–65 CE. Extant works include Letters to Lucilius and tragedies including Thyestes, Medea, Agamemnon, Oedipus.
- **Simonides**. Greek lyric poet, 555–565 BCE.
- **Sophocles**. Greek tragic poet, 495–405 BCE. Extant works include Oedipus Tyrannos, Antigone, Philoctetes, Ajax.
- **Terence**. Roman comic poet, 195–159 BCE. Extant works include Mother-In-Law.
- **Thucydides**. Athenian military historian, 460–400 BCE. History of the Peloponnesian War.

## Some modern translators/imitators

- **Samuel Butler**, 1835–1902
- **Anne Carson**, 1950–present
- **George Chapman**, 1559–1634
- **Robert Fagles**, 1933–2008
- **Robert Fitzgerald**, 1910–1985
- **Richmond Lattimore**, 1906–1984
- **Stanley Lombardo**, 1943–present
- **Alexander Pope**, 1688–1744
- **E. V. Rieu**, 1887–1972
- **Sarah Ruden**, 1962–present
- **Oliver Taplin**, 1943–present

## Other modern texts and authors

- Walter Benjamin, ‘The Task of the Translator’ (1923)
- Antoine Berman, The Experience of the Foreign (1992)
- Ruby Blondell, Helen of Troy (2015)
- E. R. Dodds, The Greeks and the Irrational (1951)
- Denis Feeney, Beyond Greek (2016)
- Edith Hamilton, Mythology (1942)
- The Loeb Classical Library (1911 onwards)
- Christopher Logue, War Music (2017)
- Louis MacNeice, Autumn Journal (1939)
- Madeline Miller, Song of Achilles (2011)
- Jeffrey Henderson, The Maculate Muse (1975)
- Friedrich Schleiermacher, ‘On the Different Methods of Translating’ (published posthumously, 1851)
- Damion Searls, The Philosophy of Translation (2025) Lawrence Venuti, The Translator’s Invisibility (1995)
