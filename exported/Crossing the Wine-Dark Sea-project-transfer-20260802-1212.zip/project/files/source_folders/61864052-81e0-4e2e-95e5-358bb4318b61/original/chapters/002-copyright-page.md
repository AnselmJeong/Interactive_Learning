# Copyright Page

First published in Great Britain in 2026 by

Profile Books Ltd

29 Cloth Fair

London

EC1A 7JQ

*[www.profilebooks.com](http://www.profilebooks.com)*

and

London Review of Books

28 Little Russell Street

London

WC1A 2HN

*[www.lrb.co.uk](http://www.lrb.co.uk)*

Copyright © Emily Wilson, 2026

‘Chill Out with the Stoics’ (2010), ‘The Trouble With Speeches’ (2013) and ‘Slut-Shaming Helen of Troy’ (2014) previously published in the *New Republic*

‘Web of Rome’ previously published in the *TLS* (2016)

‘War Music’ previously published in *Translation and Literature* Vol. 25, Issue 3 (2016) ‘The Pleasures of Translation’ previously published in the *New York Review of Books* (2018)

‘Ancient Worlds: Edith Hamilton and the Popularisation of the Classics’ previously published in the *Nation* (2023)

1 3 5 7 9 10 8 6 4 2

Typeset in Dante by CC Book Production

The moral right of the author has been asserted.

All rights reserved. Without limiting the rights under copyright reserved above, no part of this publication may be reproduced, stored or introduced into a retrieval system, or transmitted, in any form or by any means (electronic, mechanical, photocopying, recording or otherwise), without the prior written permission of both the copyright owner and the publisher of this book.

Profile Books takes seriously the responsibility of defending our authors’ copyright. No part of this book may be used or reproduced in any manner for the purpose of training artificial intelligence technologies or systems (including but not limited to machine learning models and large language models (LLMs)). In accordance with Article 4(3) of the DSM Directive 2019/790, Profile Books expressly reserves this work from the text and data mining exception.

A CIP catalogue record for this book is available from the British Library.

Our product safety representative in the EU is BGC Sustainability & Compliance, 7 avenue du Général Leclerc, Paris, 75014, France <https://baldwinglobalconsulting.com>

ISBN 978 1 80522 585 0

eISBN 978 1 80522 586 7
